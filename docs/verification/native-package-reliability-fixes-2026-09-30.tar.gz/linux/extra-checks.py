import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess

repo = Path('/home/user/workspace')
audit = Path('/home/user/final-audit')
pkg = str(repo / 'target/release/pkg')
system = 'x86_64-linux'
results = []

def run(env, *args, code=0, timeout=240):
    p = subprocess.run(args, env=env, text=True, capture_output=True, timeout=timeout)
    results.append({'command': args, 'code': p.returncode, 'stdout': p.stdout, 'stderr': p.stderr})
    (audit / 'extra-results.json').write_text(json.dumps(results, indent=2) + '\n')
    assert p.returncode == code, results[-1]
    return p.stdout

def environment(root, nixpkgs, casks):
    root.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ)
    for key, leaf in [('XDG_CONFIG_HOME', 'config'), ('XDG_STATE_HOME', 'state'), ('XDG_CACHE_HOME', 'cache')]:
        env[key] = str(root / leaf)
    config = root / 'config/pkg/config.toml'
    config.parent.mkdir(parents=True, exist_ok=True)
    config.write_text('[sources]\nnixpkgs = ' + json.dumps(nixpkgs) + '\ncasks = ' + json.dumps(casks) + '\n')
    return env, root / 'state/nix/profiles/pkg'

# Distinct casks from one source must receive distinct opaque native IDs.
root = audit / 'same-source'
source = root / 'source-casks'
source.mkdir(parents=True, exist_ok=True)
spec = importlib.util.spec_from_file_location('native_check', repo / 'tools/native-cli-check.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
(source / 'builder.c').write_text(module.BUILDER)
subprocess.run(['cc', '-static', '-DVERSION="1"', str(source / 'builder.c'), '-o', str(source / 'builder')], check=True)
index = json.loads((repo / 'crates/pkg-cli/tests/fixtures/catalog-index.json').read_text())
original = index['systems'][system]['entries']['homebrew/cask/1password-cli']
entries = {}
for token in ['alpha', 'beta']:
    e = copy.deepcopy(original)
    e.update(id='homebrew/cask/' + token, source='homebrew/cask', token=token, name=token, version='1')
    entries[e['id']] = e
index['targets'] = [system]
index['systems'] = {system: {'entries': entries}}
(source / 'index.json').write_text(json.dumps(index))
packages = []
for token in ['alpha', 'beta']:
    packages.append('"homebrew/cask/' + token + '" = builtins.derivation { name = "' + token
                    + '-1"; system = "' + system + '"; builder = ./builder; args = [ ./builder "'
                    + token + '" ]; } // { version = "1"; pname = "' + token + '"; };')
(source / 'flake.nix').write_text('{ outputs = {self}: { catalogIndex = builtins.fromJSON (builtins.readFile ./index.json); packages.'
                                  + system + ' = { ' + ' '.join(packages) + ' }; }; }')
reference = 'path:' + str(source)
env, profile = environment(root, reference, reference)
run(env, pkg, 'install', 'cask:homebrew/cask/alpha', 'cask:homebrew/cask/beta')
listed = json.loads(run(env, pkg, '--json', 'list'))['result']
ids = {e['entry_id'] for e in listed}
assert len(listed) == len(ids) == 2, listed
native = json.loads(run(env, 'nix', 'profile', 'list', '--profile', str(profile), '--json'))
assert set(native['elements']) == ids
assert run(env, str(profile / 'bin/alpha')).strip() == '1'
assert run(env, str(profile / 'bin/beta')).strip() == '1'
alpha = next(e for e in listed if e['name'] == 'homebrew/cask/alpha')
beta = next(e for e in listed if e['name'] == 'homebrew/cask/beta')
run(env, pkg, 'remove', alpha['entry_id'])
assert run(env, str(profile / 'bin/beta')).strip() == '1'
assert not (profile / 'bin/alpha').exists()
run(env, pkg, 'remove', beta['entry_id'])
assert json.loads(run(env, pkg, '--json', 'list'))['result'] == []
(audit / 'same-source-result.json').write_text(json.dumps({'distinct_ids': sorted(ids), 'remove_one_preserves_other': True, 'final_entries': []}, indent=2) + '\n')
print('PASS: same-source casks have distinct native IDs and independent removal', flush=True)

# Install and execute real packages, then test an atomic failure and rollback.
root = audit / 'real-packages'
env, profile = environment(root, 'github:NixOS/nixpkgs/567a49d1913ce81ac6e9582e3553dd90a955875f', 'path:' + str(repo / 'nix/casks'))
names = ['hello', 'ripgrep', 'jq', 'fd']
run(env, pkg, 'install', *['nixpkgs:legacyPackages.' + system + '.' + n for n in names])
versions = {}
for binary in ['hello', 'rg', 'jq', 'fd']:
    versions[binary] = run(env, str(profile / 'bin' / binary), '--version').splitlines()[0]
before = (profile / 'manifest.json').read_bytes()
run(env, pkg, 'install', 'nixpkgs:legacyPackages.' + system + '.hello')
assert (profile / 'manifest.json').read_bytes() == before
run(env, pkg, 'install', 'nixpkgs:legacyPackages.' + system + '.coreutils', 'nixpkgs:legacyPackages.' + system + '.pkg_missing_20260930', code=1)
assert (profile / 'manifest.json').read_bytes() == before
listed = json.loads(run(env, pkg, '--json', 'list'))['result']
jq = next(e for e in listed if e['name'] == 'jq')
run(env, pkg, 'remove', jq['entry_id'])
assert not (profile / 'bin/jq').exists()
run(env, pkg, 'rollback')
assert run(env, str(profile / 'bin/jq'), '--version').strip() == versions['jq']
run(env, pkg, 'install', 'cask:homebrew/cask/1password-cli')
op_version = run(env, str(profile / 'bin/op'), '--version').strip()
assert op_version == '2.39.0'
listed = json.loads(run(env, pkg, '--json', 'list'))['result']
run(env, pkg, 'remove', *[e['entry_id'] for e in listed])
assert json.loads(run(env, pkg, '--json', 'list'))['result'] == []
(audit / 'real-packages-result.json').write_text(json.dumps({'versions': versions, 'op': op_version, 'duplicate_unchanged': True, 'failed_multi_install_atomic': True, 'rollback_restored_jq': True, 'final_entries': []}, indent=2) + '\n')
print('PASS: real package install/use, duplicate, atomic failure, rollback and removal', flush=True)

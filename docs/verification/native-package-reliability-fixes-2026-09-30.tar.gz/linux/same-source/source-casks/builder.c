
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>
int main(int argc, char **argv) {
    const char *out = getenv("out");
    if (!out) { puts(VERSION); return 0; }
    if (argc != 3) return 2;
    if (!strcmp(argv[2], "slow")) sleep(10);
    char bin[4096], dst[4096];
    if (mkdir(out, 0755)) return 3;
    snprintf(bin, sizeof(bin), "%s/bin", out);
    if (mkdir(bin, 0755)) return 4;
    snprintf(dst, sizeof(dst), "%s/%s", bin, argv[2]);
    FILE *in = fopen(argv[1], "rb"), *to = fopen(dst, "wb");
    if (!in || !to) return 5;
    char buf[8192]; size_t n;
    while ((n = fread(buf, 1, sizeof(buf), in)))
        if (fwrite(buf, 1, n, to) != n) return 6;
    if (ferror(in) || fclose(to)) return 7;
    fclose(in);
    if (chmod(dst, 0755)) return 8;
    if (!strcmp(argv[2], "app-probe")) {
        char app[4096];
        snprintf(app, sizeof(app), "%s/Applications", out); mkdir(app, 0755);
        snprintf(app, sizeof(app), "%s/Applications/AppProbe.app", out); mkdir(app, 0755);
        snprintf(app, sizeof(app), "%s/Applications/AppProbe.app/Contents", out); mkdir(app, 0755);
        snprintf(app, sizeof(app), "%s/Applications/AppProbe.app/Contents/MacOS", out); mkdir(app, 0755);
        snprintf(app, sizeof(app), "%s/Applications/AppProbe.app/Contents/MacOS/app-probe", out);
        if (link(dst, app)) return 9;
        snprintf(app, sizeof(app), "%s/Applications/AppProbe.app/Contents/Info.plist", out);
        FILE *plist = fopen(app, "w");
        if (!plist) return 10;
        fputs("<?xml version=\"1.0\"?><plist version=\"1.0\"><dict>"
              "<key>CFBundleIdentifier</key><string>dev.pkg.native-check</string>"
              "<key>CFBundleExecutable</key><string>app-probe</string>"
              "<key>CFBundleName</key><string>AppProbe</string>"
              "<key>CFBundlePackageType</key><string>APPL</string>"
              "<key>CFBundleVersion</key><string>1</string>"
              "</dict></plist>", plist);
        if (fclose(plist)) return 11;
    }
    return 0;
}

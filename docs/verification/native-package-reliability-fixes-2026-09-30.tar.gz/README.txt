Final evidence for feat/cask-nix-reliability, base 58d802213be132ed8e78cd72719b8c374da4de3e.
See docs/verification/2026-09-30-native-package-reliability-fixes.md for final classification and limits.
Raw GLM notes and patch precede parent simplification. Final source is in linux/source-manifest.json.

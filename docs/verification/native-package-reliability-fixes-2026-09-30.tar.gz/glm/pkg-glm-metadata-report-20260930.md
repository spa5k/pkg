# Metadata-fix report: recursive Apple xattr-stream cleanup in extract_7zz

Scope of change (only owned files touched; nothing committed):

- `nix/casks/lib/plan.py` — the fix
- `tools/cask-build-check/plan_tests.py` — regression test 20 with pre-control

Everything else in the 914-file tree is untouched (earlier phases'
changes preserved; final `find . -type f | wc -l` = 914, no
`__pycache__` left behind).

## 1. Verified bug

On the real macOS 15.7.7 VM, Stats 3.0.13 was installed from the pinned
DMG (sha256
`be8841586446a9a1e80d4c4fd0c434d8f1182b460ca728c82dd465c1b0c23415`).
The pristine mounted `Stats.app` passes
`codesign --verify --deep --strict`. The Nix-extracted app fails,
because 7zz materializes HFS+/APFS extended-attribute streams as regular
files (or directories) named `<item>:com.apple.<attr>` at MANY NESTED
paths, for example:

- `Contents/Info.plist:com.apple.provenance`
- `Contents/MacOS:com.apple.provenance` (stream of a DIRECTORY)
- `Contents/_CodeSignature/CodeResources:com.apple.provenance`
- `Contents/Library/LoginItems/LaunchAtLogin.app/Contents/PkgInfo:com.apple.provenance`

The old cleanup in `extract_7zz` scanned ONLY direct children of the
extraction root (`os.listdir(dest)`), so every nested remnant survived
into the output bundle and broke code signing.

## 2. Fix (nix/casks/lib/plan.py)

New constant + helper, and the direct-children loop replaced by one call:

- `APPLE_STREAM_MARK = ":com.apple."` — a ":" cannot occur in a file
  name on a real macOS volume (legacy HFS path separator), so any name
  carrying this marker is a materialized xattr stream, at any depth.
  Names without the marker (ordinary colon files such as
  `notes:with:colons.txt`, or apple-NAMED files like
  `com.apple.shipped.txt`) are NOT matched — no broad colon deletion.
- `_prune_apple_streams(dest)` walks the extracted tree with
  `os.walk(dest, followlinks=False)`, never follows and never deletes
  symlinks (at this stage the tree holds only 7zz-written regular files
  and dirs; an anomalous link is left for the post-install audit),
  collects matching paths, then removes them: dir-shaped remnants via
  `shutil.rmtree(..., ignore_errors=True)`, file remnants via
  `os.remove` with `OSError` suppressed (parent rmtree may have removed
  a collected child first).
- The call runs after the safe 7zz extraction and BEFORE links are
  re-created — same ordering as before, so all existing link/traversal
  checks (`validate_members`, `resolve_graph`, `_check_target_path`,
  `link_target_ok`) are unchanged and still run.

## 3. Regression test (tools/cask-build-check/plan_tests.py, test 20)

No mocks: a REAL 7z archive is built with `7zz a -snl` reproducing the
materialization (synthetic archive is permitted for reproducing the
materialization):

- nested stream remnants at 5 nested paths, file-shaped AND dir-shaped
  (`MacOS:com.apple.provenance/inner`), including
  `Info.plist:com.apple.metadata:kMDItemWhereFroms` and the deep
  `LaunchAtLogin.app/Contents/PkgInfo:com.apple.provenance`
- ordinary nested signed resources that must be preserved: `Info.plist`,
  `MacOS/Stats`, `_CodeSignature/CodeResources`, deep `PkgInfo`
- an ordinary colon filename `Resources/notes:with:colons.txt` and an
  apple-named file without the marker
  `Resources/en.lproj/com.apple.shipped.txt` (proves no broad deletion)
- safe framework links `Versions/Current -> A` and
  `Fw -> Versions/Current/Fw` (excluded from 7zz, re-created by hand,
  must resolve in-tree)

PRE-CONTROL (not mock-only): the live `plan.py` source is copied with
only the fix reverted (the `_prune_apple_streams(dest)` call replaced by
the exact old direct-children loop); the SAME real archive and real 7zz
extraction run through it in a child interpreter. Expected and observed:
nested remnants survive (child exits with the dedicated code 3) —
`PASS: pre-control: reverted (old) cleanup leaves nested streams`.
If the live source ever stops calling `_prune_apple_streams` exactly
once, the test FAILS loudly. The new implementation then passes:
no `:com.apple.` entries anywhere, all preservation checks green.

## 4. Evidence (logs in /home/user/final-audit/logs/)

- `repro-nested-streams.py` — standalone reproducer (real 7zz archive)
- `pre-control-old-impl.txt` — OLD implementation: 5 nested leftovers
  (`RESULT: BUG: nested streams survive`), resources/links preserved
- `post-fix-new-impl.txt` — NEW implementation: `RESULT: CLEAN`
- `plan_tests-full-run.txt` — full suite, real bsdtar + 7zz + native
  APFS DMG fixture: 57 PASS, `all plan.py regression checks passed`
- `run-sh-builder.txt` — builder `run.sh` incl. the synthetic maxMacos
  projection check (`minMacos 14.2, maxMacos 15.9`): `pass=14 fail=0`

## 5. Hashes and patch

- `metadata-fix.patch` — unified diff of ONLY the two owned files
- `source-hashes.txt` — sha256 before (orig) and after for both files
  - plan.py: `89086a6c…` -> `36871fc4…`
  - plan_tests.py: `40335751…` -> `4d86c7f2…`

## 6. Notes and sequencing

- Signing, Gatekeeper policy, and vendor executables are NOT changed;
  the parent still verifies the actual Stats.app on the VM (this fix
  only removes materialized metadata remnants before the bundle is
  assembled; the native APFS DMG fixture end-to-end unpack still passes).
- Release sequencing respected: schema4 candidate code + catalog merge
  together; remote main at /3 incompatibility is expected pre-merge; no
  fallback and no feature-branch pin added.
- Nothing was committed (workspace has no git repository).

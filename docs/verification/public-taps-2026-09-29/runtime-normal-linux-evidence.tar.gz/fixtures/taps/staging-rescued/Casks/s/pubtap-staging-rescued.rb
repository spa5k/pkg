# Synthetic public-tap-check fixture. Data only; never executed here.
# Expected result: see tools/public-tap-check/matrix.json "pubtap-staging-rescued".
cask "pubtap-staging-rescued" do
  version "1.0.0"
  sha256 "1fb4d854f38ee167a3a2cedc74138f6a4e2508beea62e9eb1abe40584a949994"
  url "https://example.com/pubtap/pubtap-staging-rescued/pubtap-staging-rescued-1.0.0.zip"
  name "PubTap Staging Rescued"
  desc "Staging access rescued to a static fallback (synthetic fixture)"
  homepage "https://example.com/pubtap/pubtap-staging-rescued"

  app "StagingTool.app"
  begin
    binary "#{staged_path}/bin/staging-tool"
  rescue StandardError
    binary "staging-tool"
  end
end

# Synthetic public-tap-check fixture. Data only; never executed here.
# Expected result: see tools/public-tap-check/matrix.json "pubtap-staging-rescued-control".
cask "pubtap-staging-rescued-control" do
  version "1.0.0"
  sha256 "11f3dcb41d46e941bfd8e611ed8725eb9929c0231c87cd7d638a983970d68b13"
  url "https://example.com/pubtap/pubtap-staging-rescued-control/pubtap-staging-rescued-control-1.0.0.zip"
  name "PubTap Staging Rescued Control"
  desc "Valid positive control for its isolated tree (synthetic fixture)"
  homepage "https://example.com/pubtap/pubtap-staging-rescued-control"

  on_macos do
    binary "bin/pubtap-staging-rescued-control"
  end
  on_linux do
    binary "bin/pubtap-staging-rescued-control"
  end
end

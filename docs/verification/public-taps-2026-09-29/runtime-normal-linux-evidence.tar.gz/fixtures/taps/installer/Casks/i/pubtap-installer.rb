# Synthetic public-tap-check fixture. Data only; never executed here.
# Expected result: see tools/public-tap-check/matrix.json "pubtap-installer".
cask "pubtap-installer" do
  version "5.0.0"
  sha256 "53a4364bb307e2de87107283ddaffd30682c0b94e8672222dcbc2efac6731c23"
  url "https://example.com/pubtap/pubtap-installer/pubtap-installer-5.0.0.dmg"
  name "PubTap Installer"
  desc "Installer script stanza (synthetic fixture)"
  homepage "https://example.com/pubtap/pubtap-installer"

  installer script: {
    executable: "install.sh",
    args: ["--fixture"],
  }
end

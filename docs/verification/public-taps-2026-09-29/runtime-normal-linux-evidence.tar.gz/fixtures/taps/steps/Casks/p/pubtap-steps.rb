# Synthetic public-tap-check fixture. Data only; never executed here.
# Expected result: see tools/public-tap-check/matrix.json "pubtap-steps".
cask "pubtap-steps" do
  version "1.1.0"
  sha256 "23ae492e5d9715be14c1452f206e76a3e4112c730fa2608e097bc1c503c496ad"
  url "https://example.com/pubtap/pubtap-steps/pubtap-steps-1.1.0.zip"
  name "PubTap Steps"
  desc "Structured postflight_steps with a run stanza (synthetic fixture)"
  homepage "https://example.com/pubtap/pubtap-steps"

  app "StepsTool.app"
  postflight_steps do
    run "/usr/bin/true", args: []
  end
end

# Synthetic public-tap-check fixture. Data only; never executed here.
# Expected result: see tools/public-tap-check/matrix.json "pubtap-broken-control".
cask "pubtap-broken-control" do
  version "1.0.0"
  sha256 "87afacbd2439e05c3d6536aaa131eaca4a66308620cf64e330a62feb13e33686"
  url "https://example.com/pubtap/pubtap-broken-control/pubtap-broken-control-1.0.0.zip"
  name "PubTap Broken Control"
  desc "Valid positive control for its isolated tree (synthetic fixture)"
  homepage "https://example.com/pubtap/pubtap-broken-control"

  on_macos do
    binary "bin/pubtap-broken-control"
  end
  on_linux do
    binary "bin/pubtap-broken-control"
  end
end

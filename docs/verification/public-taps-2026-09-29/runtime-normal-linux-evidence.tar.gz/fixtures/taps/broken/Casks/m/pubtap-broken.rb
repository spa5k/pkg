# Synthetic fixture: intentionally invalid Ruby.
# Expected: one excluded record with code record-load-error.
cask "pubtap-broken" do
  version "1.0.0"
  this is not valid ruby {{{
end

# Synthetic public-tap-check fixture. Data only; never executed here.
# Expected result: see tools/public-tap-check/matrix.json "viewer".
cask "viewer" do
  version "2.1.0"
  sha256 "78c8a7455d9321c5704c61658b5ef00f5fa17873a5e6726d37cda0e40cfae691"
  url "https://example.com/pubtap/viewer/viewer-2.1.0.dmg"
  name "Alpha Viewer"
  desc "Excluded collision token, alpha side (synthetic fixture)"
  homepage "https://example.com/pubtap/viewer"

  installer script: {
    executable: "#{staged_path}/Viewer Installer.app/Contents/MacOS/install",
  }
end

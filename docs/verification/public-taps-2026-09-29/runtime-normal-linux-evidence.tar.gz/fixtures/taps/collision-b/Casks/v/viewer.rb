# Synthetic public-tap-check fixture. Data only; never executed here.
# Expected result: see tools/public-tap-check/matrix.json "viewer".
cask "viewer" do
  version "9.0.1"
  sha256 "788304f1094ea71e3ab558019d6cf8980cddbb19624788f77215772a08565420"
  url "https://example.com/pubtap/viewer/viewer-9.0.1.zip"
  name "Beta Viewer"
  desc "Eligible collision token, beta side (synthetic fixture)"
  homepage "https://example.com/pubtap/viewer"

  on_macos do
    app "BetaViewer.app"
  end
  on_linux do
    binary "beta-viewer"
  end
end

# Synthetic public-tap-check fixture. Data only; never executed here.
# Expected result: see tools/public-tap-check/matrix.json "editor".
cask "editor" do
  version "4.5.0"
  sha256 "fef84875a85ff5cc2a9de304832a9fffa031940014fce1c213f6e5c1616a686b"
  url "https://example.com/pubtap/editor/editor-4.5.0.zip"
  name "Beta Editor"
  desc "Cross-tap collision token, beta side (synthetic fixture)"
  homepage "https://example.com/pubtap/editor"

  on_macos do
    binary "beta-editor"
  end
  on_linux do
    binary "beta-editor"
  end
end

# Synthetic public-tap-check fixture. Data only; never executed here.
# Expected result: see tools/public-tap-check/matrix.json "pubtap-app-bundle".
cask "pubtap-app-bundle" do
  version "3.1.4"
  sha256 "a429cd3313332eb4045df7074c21df7448529cfe43726283c8e3640cb5486e8f"
  url "https://example.com/pubtap/pubtap-app-bundle/pubtap-app-bundle-3.1.4.dmg"
  name "PubTap App Bundle"
  desc "macOS app bundle in a dmg (synthetic fixture)"
  homepage "https://example.com/pubtap/pubtap-app-bundle"

  depends_on macos: :sonoma
  app "PubTapBundle.app"
end

# Bounded output flood: emits exactly 2097152 bytes of stdout,
# then stops. Fixed budget; no environment override exists. The
# runner must still cap captured output while the command runs.
chunk = "PUBTAP-FLOOD " + ("x" * 99) + "\n"
budget = 2097152
emitted = 0
while emitted + chunk.bytesize <= budget
  puts chunk
  emitted += chunk.bytesize
end
puts "PUBTAP-FLOOD-DONE emitted=#{emitted}"
# Synthetic public-tap-check fixture. Data only; never executed here.
# Expected result: see tools/public-tap-check/matrix.json "pubtap-flood".
cask "pubtap-flood" do
  version "1.0.0"
  sha256 "6a5241383070fd81e6f10dbbca20c4eed5174ff73320afb754e3f65d70288219"
  url "https://example.com/pubtap/pubtap-flood/pubtap-flood-1.0.0.zip"
  name "PubTap Flood"
  desc "Output exhaustion probe (synthetic fixture)"
  homepage "https://example.com/pubtap/pubtap-flood"

  app "FloodTool.app"
end

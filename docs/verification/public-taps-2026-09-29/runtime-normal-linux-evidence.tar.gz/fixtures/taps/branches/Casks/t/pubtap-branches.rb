# OS/arch/language branches plus a local helper; the helper is part
# of whole-tree identity (see helper-only-invalidation).
require_relative "../../lib/pubtap_helper"
cask "pubtap-branches" do
  version PubtapHelper::VERSION
  arch arm: "aarch64", intel: "x86_64"
  sha256 arm: "e55c0934d0115efec6aef8eaa7e17a6554f04fddf0690825058863f69bdab61b", intel: "e974b81633767e8cb12ad159b21ec3e533946217c5bea041ff73b14531c6128d"
  name "Branch Tool"
  desc "OS, arch, and language branches (synthetic fixture)"
  homepage "https://example.com/pubtap/pubtap-branches"
  language "en", default: true do
    url "https://example.com/pubtap/pubtap-branches/#{version}/branches-#{arch}-en.zip"
    "en"
  end
  language "de" do
    url "https://example.com/pubtap/pubtap-branches/#{version}/branches-#{arch}-de.zip"
    "de"
  end
  on_macos do
    depends_on macos: :ventura
    app "BranchTool.app"
  end
  on_linux do
    binary "branchtool"
  end
end

# Branch helper; part of tree identity.
module PubtapHelper
  VERSION = "1.2.3".freeze

  def self.version
    VERSION
  end
end

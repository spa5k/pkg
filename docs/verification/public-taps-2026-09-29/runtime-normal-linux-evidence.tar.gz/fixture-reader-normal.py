import json,platform,subprocess,sys
from pathlib import Path
base=Path('/tmp/pkg-runtime-normal')
system='aarch64-darwin' if platform.system()=='Darwin' else 'x86_64-linux'
cases=list(json.loads((base/'public-tap-check/matrix.json').read_text())['source_id'])
records=[]
for case in cases:
 r=subprocess.run([sys.executable,str(base/'runtime-smoke.py'),str(base),case],capture_output=True,text=True,timeout=300)
 result_file=base/f'result-{system}-{case.replace("/","-")}.json'
 result=json.loads(result_file.read_text()) if result_file.exists() else {}
 record={'case':case,'exit':r.returncode,'files':result.get('capture',{}).get('files'),'error':r.stderr[-1000:]}
 records.append(record);print(json.dumps(record),flush=True)
(base/'fixture-matrix-summary.json').write_text(json.dumps(records,indent=2))
assert all(r['exit']==0 for r in records),records

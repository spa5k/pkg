# typed: false
# frozen_string_literal: true

# pkg raw-tap bounded child reader (shared by export.rb and
# tests/reader_test.rb). PRODUCTION LIMITS ARE FIXED CONSTANTS:
#   RECORD_CAP_BYTES       2 MiB  per serialized child record
#   EXPORT_CAP_BYTES      32 MiB  cumulative records + final envelope
#   CHILD_DEADLINE_SECONDS 60 s   per child (read + bounded exit wait)
# The single record reader takes its cap and deadline as explicit
# arguments so behavioral tests can pass SHORT values; production
# callers always pass the constants above. No environment knob can
# change any production bound.
module PkgTapReader
  # 2 MiB per serialized record: headroom above the largest legitimate
  # upstream cask to_h (artifact/zap arrays included) while keeping each
  # child pipe read far below the 32 MiB envelope cap.
  RECORD_CAP_BYTES = 2_097_152.freeze
  # Per-child read + bounded exit wait wall clock. Well-behaved casks
  # finish in well under a minute; a stuck child is killed as a group
  # at the deadline.
  CHILD_DEADLINE_SECONDS = 60.freeze
  # Total export byte budget (records + envelope). Matches the 32 MiB
  # cap the Rust consumer enforces on the final export.json.
  EXPORT_CAP_BYTES = 33_554_432.freeze

  # Cumulative-cap / overflow violation. export.rb turns this into a
  # whole-export failure (non-zero exit, no output file); tests rescue
  # it to assert the mapping without running the exporter.
  class ExportCapExceeded < StandardError; end

  module_function

  # The child runs in its own process group (Process.setpgrp in the
  # child); kill_child_group therefore SIGKILLs the child AND any
  # grandchildren, even if the child trapped SIGTERM.
  def kill_child_group(pid)
    Process.kill("KILL", -pid) # whole process group
  rescue Errno::ESRCH, Errno::EPERM
    begin
      Process.kill("KILL", pid)
    rescue Errno::ESRCH, Errno::EPERM
      nil
    end
  end

  def reap_child(pid)
    Process.wait2(pid)
  rescue Errno::ECHILD, Errno::EINVAL
    [nil, nil]
  end

  # After a child has exited (normally or killed), SIGKILL any process
  # still in its group so grandchildren cannot outlive the export. No
  # unbounded wait: grandchildren are not our direct children, so the
  # reap is best-effort and cannot block.
  def finalize_child_group(pid)
    kill_child_group(pid)
    reap_child(pid)
  end

  def group_alive?(pid)
    Process.kill(0, -pid)
    true
  rescue Errno::ESRCH, Errno::EPERM
    false
  end

  # Forks a record child: binmode pipe, own process group. The block
  # runs IN the child and writes its record(s) to the given writable;
  # the child exits via exit! (no at_exit hooks). Returns
  # [readable, pid] in the parent.
  def fork_record_child(&block)
    readable, writable = IO.pipe
    # Explicit binary pipe protocol: read buffers stay ASCII-8BIT
    # regardless of the parent locale (LC_ALL=C gives US-ASCII pipes).
    readable.binmode
    writable.binmode
    pid = Process.fork do
      Process.setpgrp
      readable.close
      block.call(writable)
      writable.close
      exit! 0
    end
    writable.close
    [readable, pid]
  end

  # Reads one record line from the child pipe under a byte cap and a
  # monotonic deadline. Returns [line, reason] where reason is :ok,
  # :overflow (cap exceeded; the group is SIGKILLed immediately so an
  # oversized writer that then hangs cannot block cleanup — integrity
  # violation, caller must fail the WHOLE export), or :deadline (group
  # also SIGKILLed; caller records a per-file error). Uses IO.select +
  # read_nonblock; no unbounded gets, no blocking wait.
  def read_child_line(readable, pid, cap:, deadline:)
    deadline_at = Process.clock_gettime(Process::CLOCK_MONOTONIC) + deadline
    buf = String.new(capacity: 8192, encoding: Encoding::ASCII_8BIT)
    loop do
      remaining = deadline_at - Process.clock_gettime(Process::CLOCK_MONOTONIC)
      if remaining <= 0
        kill_child_group(pid)
        return [nil, :deadline]
      end

      ready, = IO.select([readable], nil, nil, remaining)
      next unless ready

      loop do
        chunk = readable.read_nonblock(8192, exception: false)
        case chunk
        when :wait_readable
          break
        when nil # EOF: the child side of the pipe is closed
          return [buf, :ok]
        else
          buf << chunk
          if buf.bytesize > cap
            kill_child_group(pid)
            return [nil, :overflow]
          end
        end
      end
    end
  end

  # Reinterprets one raw child line (ASCII-8BIT pipe bytes) as UTF-8
  # WITHOUT any conversion: valid multi-byte sequences are preserved
  # EXACTLY (String#encode would corrupt them byte-by-byte). Returns
  # [text, nil] when the bytes are valid UTF-8, or [nil, reason] when
  # they are not: the caller must turn an invalid payload into a
  # bounded per-file error record. Metadata is never silently scrubbed.
  def decode_record_line(line)
    text = line.dup.force_encoding(Encoding::UTF_8)
    return [nil, "invalid UTF-8 byte sequence in child record"] unless text.valid_encoding?

    [text.strip, nil]
  end

  # Bounded wait for the child to exit after EOF. A child that closed
  # its pipe but then hangs (or leaves a TERM-trapping grandchild
  # behind) is SIGKILLed as a group at the deadline and reported as a
  # killed child, never allowed to block the export.
  def wait_child_bounded(pid, deadline_at)
    loop do
      _, status = Process.wait2(pid, Process::WNOHANG)
      return status if status

      remaining = deadline_at - Process.clock_gettime(Process::CLOCK_MONOTONIC)
      if remaining <= 0
        kill_child_group(pid)
        _, status = reap_child(pid)
        return status || :killed
      end
      IO.select(nil, nil, nil, [remaining, 0.05].min)
    end
  rescue Errno::ECHILD
    nil
  end

  # Cumulative bound: charged as records accumulate, so the envelope
  # is never even built past the budget. Pure accounting helper: it
  # raises ExportCapExceeded (caller turns that into a whole-export
  # failure) or returns the new running total.
  def charge_record_bytes!(total, bytes, cap, stem)
    total += bytes
    raise ExportCapExceeded,
          "cumulative record bytes (#{total}) exceeded the #{cap}-byte export cap at #{stem}; whole export fails" if total > cap

    total
  end
end

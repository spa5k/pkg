import hashlib, json, os, platform, secrets, socket, subprocess, sys, tempfile, threading
from pathlib import Path
base = Path(sys.argv[1]).resolve()
case = sys.argv[2] if len(sys.argv) > 2 else 'release-archive'
fixtures = base / 'fixtures'
if not fixtures.exists():
    subprocess.run([sys.executable, str(base / 'public-tap-check/make_fixtures.py'), '--out', str(fixtures)], check=True)
root = Path(tempfile.mkdtemp(prefix='pkg-runtime-gate-', dir='/tmp'))
root.chmod(0o777)
canary = root / 'canary'
nonce = secrets.token_hex(32)
canary.write_text(nonce)
canary.chmod(0o644)
assert canary.read_text() == nonce
server = socket.socket()
server.bind(('127.0.0.1', 0)); server.listen(8)
port = server.getsockname()[1]
with socket.create_connection(('127.0.0.1', port), timeout=2): pass
conn, _ = server.accept(); conn.close()
def accept_loop():
    try:
        while True:
            conn, _ = server.accept(); conn.close()
    except OSError: pass
threading.Thread(target=accept_loop, daemon=True).start()
system = 'aarch64-darwin' if platform.system() == 'Darwin' else 'x86_64-linux'
matrix = json.loads((base/'public-tap-check/matrix.json').read_text())
source = matrix['source_id'][case]
revision = next((r['revision'] for r in json.loads((base/'public-tap-check/public-sources.json').read_text())['sources'] if r['source'] == source), 'a'*40)
expr = f'''import {base}/tap/raw-export.nix {{
 pkgs = import (builtins.getFlake "github:NixOS/nixpkgs/567a49d1913ce81ac6e9582e3553dd90a955875f").outPath {{ system = "{system}"; }};
 tapSource = {fixtures}/taps/{case};
 source = {json.dumps(source)};
 revision = "{revision}";
 system = "{system}";
 canary = {{ path = {json.dumps(str(canary))}; sha256 = "{hashlib.sha256(nonce.encode()).hexdigest()}"; port = {port}; }};
}}'''
(root/'check.nix').write_text(expr)
env = os.environ.copy(); env['PATH']='/nix/var/nix/profiles/default/bin:'+env['PATH']
try:
    run = subprocess.run(['nix','build','--impure','--no-link','--print-out-paths','-L','--file',str(root/'check.nix')],env=env,capture_output=True,text=True,timeout=590)
    result={'system':system,'case':case,'canary_positive_control':True,'loopback_positive_control':True,'returncode':run.returncode,'stdout':run.stdout,'stderr':run.stderr[-30000:]}
    if run.returncode==0:
        out=Path(run.stdout.strip().splitlines()[-1]); result['capture']=json.loads((out/'export.json').read_text())
    (base/f'result-{system}-{case.replace("/","-")}.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result),flush=True)
    run.check_returncode()
finally:
    server.close()

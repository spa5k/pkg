#compdef pkg

autoload -U is-at-least

_pkg() {
    typeset -A opt_args
    typeset -a _arguments_options
    local ret=1

    if is-at-least 5.2; then
        _arguments_options=(-s -S -C)
    else
        _arguments_options=(-s -C)
    fi

    local context curcontext="$curcontext" state line
    _arguments "${_arguments_options[@]}" : \
'--json[Emit versioned JSON for query commands (search, info, list, doctor)]' \
'--no-color[Disable colored output]' \
'--verbose[Show the native Nix command lines that pkg runs]' \
'-h[Print help]' \
'--help[Print help]' \
'-V[Print version]' \
'--version[Print version]' \
":: :_pkg_commands" \
"*::: :->pkg" \
&& ret=0
    case $state in
    (pkg)
        words=($line[1] "${words[@]}")
        (( CURRENT += 1 ))
        curcontext="${curcontext%:*:*}:pkg-command-$line[1]:"
        case $line[1] in
            (search)
_arguments "${_arguments_options[@]}" : \
'--json[Emit versioned JSON for query commands (search, info, list, doctor)]' \
'--no-color[Disable colored output]' \
'--verbose[Show the native Nix command lines that pkg runs]' \
'-h[Print help]' \
'--help[Print help]' \
':query -- Regex query. The nixpkgs lane passes it to native `nix search`; the cask lane matches it locally (Rust regex, case-insensitive) against token, name, and description:_default' \
&& ret=0
;;
(info)
_arguments "${_arguments_options[@]}" : \
'--json[Emit versioned JSON for query commands (search, info, list, doctor)]' \
'--no-color[Disable colored output]' \
'--verbose[Show the native Nix command lines that pkg runs]' \
'-h[Print help]' \
'--help[Print help]' \
':id -- Catalog ID such as nixpkgs\:ripgrep, cask\:raycast, or a bare name:_default' \
&& ret=0
;;
(install)
_arguments "${_arguments_options[@]}" : \
'--json[Emit versioned JSON for query commands (search, info, list, doctor)]' \
'--no-color[Disable colored output]' \
'--verbose[Show the native Nix command lines that pkg runs]' \
'-h[Print help]' \
'--help[Print help]' \
'*::ids -- Catalog IDs or supported public GitHub flake installables:_default' \
&& ret=0
;;
(list)
_arguments "${_arguments_options[@]}" : \
'--json[Emit versioned JSON for query commands (search, info, list, doctor)]' \
'--no-color[Disable colored output]' \
'--verbose[Show the native Nix command lines that pkg runs]' \
'-h[Print help]' \
'--help[Print help]' \
&& ret=0
;;
(remove)
_arguments "${_arguments_options[@]}" : \
'--json[Emit versioned JSON for query commands (search, info, list, doctor)]' \
'--no-color[Disable colored output]' \
'--verbose[Show the native Nix command lines that pkg runs]' \
'-h[Print help]' \
'--help[Print help]' \
'*::entries -- Exact native entry IDs as shown by `pkg list`:_default' \
&& ret=0
;;
(update)
_arguments "${_arguments_options[@]}" : \
'--json[Emit versioned JSON for query commands (search, info, list, doctor)]' \
'--no-color[Disable colored output]' \
'--verbose[Show the native Nix command lines that pkg runs]' \
'-h[Print help]' \
'--help[Print help]' \
&& ret=0
;;
(upgrade)
_arguments "${_arguments_options[@]}" : \
'()--all[Upgrade every installed entry, reporting fixed ones explicitly]' \
'--json[Emit versioned JSON for query commands (search, info, list, doctor)]' \
'--no-color[Disable colored output]' \
'--verbose[Show the native Nix command lines that pkg runs]' \
'-h[Print help]' \
'--help[Print help]' \
'*::entries -- Exact native entry IDs to upgrade:_default' \
&& ret=0
;;
(history)
_arguments "${_arguments_options[@]}" : \
'--json[Emit versioned JSON for query commands (search, info, list, doctor)]' \
'--no-color[Disable colored output]' \
'--verbose[Show the native Nix command lines that pkg runs]' \
'-h[Print help]' \
'--help[Print help]' \
&& ret=0
;;
(rollback)
_arguments "${_arguments_options[@]}" : \
'--json[Emit versioned JSON for query commands (search, info, list, doctor)]' \
'--no-color[Disable colored output]' \
'--verbose[Show the native Nix command lines that pkg runs]' \
'-h[Print help]' \
'--help[Print help]' \
'::generation -- Generation number to select. Defaults to the previous generation:_default' \
&& ret=0
;;
(prune)
_arguments "${_arguments_options[@]}" : \
'--older-than=[Retention age such as \`30d\`. Required and strictly positive]:AGE:_default' \
'--json[Emit versioned JSON for query commands (search, info, list, doctor)]' \
'--no-color[Disable colored output]' \
'--verbose[Show the native Nix command lines that pkg runs]' \
'-h[Print help]' \
'--help[Print help]' \
&& ret=0
;;
(doctor)
_arguments "${_arguments_options[@]}" : \
'--json[Emit versioned JSON for query commands (search, info, list, doctor)]' \
'--no-color[Disable colored output]' \
'--verbose[Show the native Nix command lines that pkg runs]' \
'-h[Print help]' \
'--help[Print help]' \
&& ret=0
;;
(shellenv)
_arguments "${_arguments_options[@]}" : \
'--json[Emit versioned JSON for query commands (search, info, list, doctor)]' \
'--no-color[Disable colored output]' \
'--verbose[Show the native Nix command lines that pkg runs]' \
'-h[Print help]' \
'--help[Print help]' \
&& ret=0
;;
(completion)
_arguments "${_arguments_options[@]}" : \
'--json[Emit versioned JSON for query commands (search, info, list, doctor)]' \
'--no-color[Disable colored output]' \
'--verbose[Show the native Nix command lines that pkg runs]' \
'-h[Print help (see more with '\''--help'\'')]' \
'--help[Print help (see more with '\''--help'\'')]' \
':shell -- Target shell:((bash\:"Bourne Again Shell"
zsh\:"Z Shell"
fish\:"Friendly Interactive Shell"))' \
&& ret=0
;;
(apps)
_arguments "${_arguments_options[@]}" : \
'--json[Emit versioned JSON for query commands (search, info, list, doctor)]' \
'--no-color[Disable colored output]' \
'--verbose[Show the native Nix command lines that pkg runs]' \
'-h[Print help]' \
'--help[Print help]' \
":: :_pkg__subcmd__apps_commands" \
"*::: :->apps" \
&& ret=0

    case $state in
    (apps)
        words=($line[1] "${words[@]}")
        (( CURRENT += 1 ))
        curcontext="${curcontext%:*:*}:pkg-apps-command-$line[1]:"
        case $line[1] in
            (sync)
_arguments "${_arguments_options[@]}" : \
'--json[Emit versioned JSON for query commands (search, info, list, doctor)]' \
'--no-color[Disable colored output]' \
'--verbose[Show the native Nix command lines that pkg runs]' \
'-h[Print help]' \
'--help[Print help]' \
&& ret=0
;;
        esac
    ;;
esac
;;
(tap)
_arguments "${_arguments_options[@]}" : \
'--json[Emit versioned JSON for query commands (search, info, list, doctor)]' \
'--no-color[Disable colored output]' \
'--verbose[Show the native Nix command lines that pkg runs]' \
'-h[Print help]' \
'--help[Print help]' \
":: :_pkg__subcmd__tap_commands" \
"*::: :->tap" \
&& ret=0

    case $state in
    (tap)
        words=($line[1] "${words[@]}")
        (( CURRENT += 1 ))
        curcontext="${curcontext%:*:*}:pkg-tap-command-$line[1]:"
        case $line[1] in
            (add)
_arguments "${_arguments_options[@]}" : \
'--revision=[Exact 40-hex commit id to import instead of the default branch]:SHA:_default' \
'--trust[Approve the tap origin without an interactive prompt]' \
'--json[Emit versioned JSON for query commands (search, info, list, doctor)]' \
'--no-color[Disable colored output]' \
'--verbose[Show the native Nix command lines that pkg runs]' \
'-h[Print help]' \
'--help[Print help]' \
':source -- Tap source\: `owner/tap` or `https\://github.com/owner/homebrew-tap`:_default' \
&& ret=0
;;
(list)
_arguments "${_arguments_options[@]}" : \
'--json[Emit versioned JSON for query commands (search, info, list, doctor)]' \
'--no-color[Disable colored output]' \
'--verbose[Show the native Nix command lines that pkg runs]' \
'-h[Print help]' \
'--help[Print help]' \
&& ret=0
;;
(update)
_arguments "${_arguments_options[@]}" : \
'--revision=[Exact 40-hex commit id to import instead of the default branch]:SHA:_default' \
'--json[Emit versioned JSON for query commands (search, info, list, doctor)]' \
'--no-color[Disable colored output]' \
'--verbose[Show the native Nix command lines that pkg runs]' \
'-h[Print help]' \
'--help[Print help]' \
'::source -- Tap source to update. Updates every tap when omitted:_default' \
&& ret=0
;;
(remove)
_arguments "${_arguments_options[@]}" : \
'--json[Emit versioned JSON for query commands (search, info, list, doctor)]' \
'--no-color[Disable colored output]' \
'--verbose[Show the native Nix command lines that pkg runs]' \
'-h[Print help]' \
'--help[Print help]' \
':source -- Tap source to remove:_default' \
&& ret=0
;;
        esac
    ;;
esac
;;
        esac
    ;;
esac
}

(( $+functions[_pkg_commands] )) ||
_pkg_commands() {
    local commands; commands=(
'search:Search supported sources' \
'info:Show source, attribute, revision, and limits for one ID' \
'install:Resolve all IDs, then add them in one native profile operation' \
'list:List installed entries from the dedicated native profile' \
'remove:Remove exact installed entries in one native operation' \
'update:Refresh disposable discovery data. Does not change the profile' \
'upgrade:Upgrade installed entries following their original references' \
'history:Display native profile generations' \
'rollback:Switch to the previous or a selected native generation' \
'prune:Delete non-current profile generations older than an explicit age' \
'doctor:Read runtime, profile, and launcher status. Never repairs' \
'shellenv:Print idempotent Bash/Zsh path settings for this profile' \
'completion:Generate shell completion for the reduced grammar' \
'apps:Derived macOS app launcher operations' \
'tap:Manage local public Homebrew Cask taps' \
    )
    _describe -t commands 'pkg commands' commands "$@"
}
(( $+functions[_pkg__subcmd__apps_commands] )) ||
_pkg__subcmd__apps_commands() {
    local commands; commands=(
'sync:Rebuild pkg-owned launchers from the active profile' \
    )
    _describe -t commands 'pkg apps commands' commands "$@"
}
(( $+functions[_pkg__subcmd__apps__subcmd__sync_commands] )) ||
_pkg__subcmd__apps__subcmd__sync_commands() {
    local commands; commands=()
    _describe -t commands 'pkg apps sync commands' commands "$@"
}
(( $+functions[_pkg__subcmd__completion_commands] )) ||
_pkg__subcmd__completion_commands() {
    local commands; commands=()
    _describe -t commands 'pkg completion commands' commands "$@"
}
(( $+functions[_pkg__subcmd__doctor_commands] )) ||
_pkg__subcmd__doctor_commands() {
    local commands; commands=()
    _describe -t commands 'pkg doctor commands' commands "$@"
}
(( $+functions[_pkg__subcmd__history_commands] )) ||
_pkg__subcmd__history_commands() {
    local commands; commands=()
    _describe -t commands 'pkg history commands' commands "$@"
}
(( $+functions[_pkg__subcmd__info_commands] )) ||
_pkg__subcmd__info_commands() {
    local commands; commands=()
    _describe -t commands 'pkg info commands' commands "$@"
}
(( $+functions[_pkg__subcmd__install_commands] )) ||
_pkg__subcmd__install_commands() {
    local commands; commands=()
    _describe -t commands 'pkg install commands' commands "$@"
}
(( $+functions[_pkg__subcmd__list_commands] )) ||
_pkg__subcmd__list_commands() {
    local commands; commands=()
    _describe -t commands 'pkg list commands' commands "$@"
}
(( $+functions[_pkg__subcmd__prune_commands] )) ||
_pkg__subcmd__prune_commands() {
    local commands; commands=()
    _describe -t commands 'pkg prune commands' commands "$@"
}
(( $+functions[_pkg__subcmd__remove_commands] )) ||
_pkg__subcmd__remove_commands() {
    local commands; commands=()
    _describe -t commands 'pkg remove commands' commands "$@"
}
(( $+functions[_pkg__subcmd__rollback_commands] )) ||
_pkg__subcmd__rollback_commands() {
    local commands; commands=()
    _describe -t commands 'pkg rollback commands' commands "$@"
}
(( $+functions[_pkg__subcmd__search_commands] )) ||
_pkg__subcmd__search_commands() {
    local commands; commands=()
    _describe -t commands 'pkg search commands' commands "$@"
}
(( $+functions[_pkg__subcmd__shellenv_commands] )) ||
_pkg__subcmd__shellenv_commands() {
    local commands; commands=()
    _describe -t commands 'pkg shellenv commands' commands "$@"
}
(( $+functions[_pkg__subcmd__tap_commands] )) ||
_pkg__subcmd__tap_commands() {
    local commands; commands=(
'add:Approve and import a public Homebrew Cask tap. Asks for consent before any tap code runs; \`--trust\` approves without a prompt' \
'list:List registered taps and their published revisions' \
'update:Re-import one tap or every registered tap at a newer revision. Runs tap code again; recorded consent covers it' \
'remove:Unregister a tap. Keeps installed packages and old generations' \
    )
    _describe -t commands 'pkg tap commands' commands "$@"
}
(( $+functions[_pkg__subcmd__tap__subcmd__add_commands] )) ||
_pkg__subcmd__tap__subcmd__add_commands() {
    local commands; commands=()
    _describe -t commands 'pkg tap add commands' commands "$@"
}
(( $+functions[_pkg__subcmd__tap__subcmd__list_commands] )) ||
_pkg__subcmd__tap__subcmd__list_commands() {
    local commands; commands=()
    _describe -t commands 'pkg tap list commands' commands "$@"
}
(( $+functions[_pkg__subcmd__tap__subcmd__remove_commands] )) ||
_pkg__subcmd__tap__subcmd__remove_commands() {
    local commands; commands=()
    _describe -t commands 'pkg tap remove commands' commands "$@"
}
(( $+functions[_pkg__subcmd__tap__subcmd__update_commands] )) ||
_pkg__subcmd__tap__subcmd__update_commands() {
    local commands; commands=()
    _describe -t commands 'pkg tap update commands' commands "$@"
}
(( $+functions[_pkg__subcmd__update_commands] )) ||
_pkg__subcmd__update_commands() {
    local commands; commands=()
    _describe -t commands 'pkg update commands' commands "$@"
}
(( $+functions[_pkg__subcmd__upgrade_commands] )) ||
_pkg__subcmd__upgrade_commands() {
    local commands; commands=()
    _describe -t commands 'pkg upgrade commands' commands "$@"
}

if [ "$funcstack[1]" = "_pkg" ]; then
    _pkg "$@"
else
    compdef _pkg pkg
fi

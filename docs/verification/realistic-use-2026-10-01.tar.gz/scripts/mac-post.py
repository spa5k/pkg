import os,json,pathlib,subprocess,time,signal,pty,select
out=pathlib.Path('/Users/admin/pkg-live-evidence');logs=[];pkg='/Users/admin/.local/bin/pkg';env=dict(os.environ);env['PATH']='/Users/admin/.local/state/nix/profiles/pkg/bin:/Users/admin/.local/bin:/nix/var/nix/profiles/default/bin:'+env['PATH']
def run(label,args,timeout=300,e=None):
 t=time.monotonic();p=subprocess.Popen(args,env=e or env,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True)
 try:so,se=p.communicate(timeout=timeout)
 except subprocess.TimeoutExpired:
  p.send_signal(signal.SIGINT)
  try:so,se=p.communicate(timeout=30)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);so,se=p.communicate()
 item=dict(label=label,args=args,code=p.returncode,stdout=so,stderr=se,seconds=round(time.monotonic()-t,2));logs.append(item);(out/'post-commands.json').write_text(json.dumps(logs,indent=2));print(label,p.returncode,flush=True);return item
def P(label,*args,timeout=300):return run(label,[pkg,*args],timeout)
P('restore-final-app-and-sqlite-set','install','cask:stats','nixpkgs:sqlite',timeout=600)
# Assess the actual vendor app paths recorded by the launcher sync.
mapfile=pathlib.Path('/Users/admin/Applications/pkg/.pkg-launcher-sources')
if mapfile.exists():
 data=mapfile.read_text();(out/'launcher-sources.tsv').write_text(data)
 paths=[]
 for line in data.splitlines():
  name,path=line.split('\t',1)
  if '/libexec/pkg/app-sources/' in path:
   store=path.split('/libexec/pkg/app-sources/')[0]
   path='/nix/var/pkg/cask-apps/501/'+pathlib.Path(store).name+'/'+name
  paths.append(path)
 for i,path in enumerate(paths):run('vendor-codesign-'+str(i),['codesign','--verify','--deep','--strict',path])
# A real unowned user folder must survive a package change.
dest=pathlib.Path('/Users/admin/Applications/pkg');backup=dest.with_name('pkg-owned-backup');dest.rename(backup);dest.mkdir();sentinel=dest/'user-file.txt';sentinel.write_text('owned by user, not pkg\n')
P('install-with-unowned-launcher-folder','install','nixpkgs:tree',timeout=600)
assert sentinel.read_text()=='owned by user, not pkg\n'
(out/'unowned-sentinel-preserved.txt').write_text(sentinel.read_text());sentinel.unlink();dest.rmdir();backup.rename(dest)
before=subprocess.check_output([pkg,'--json','list'],env=env);P('recover-launchers-after-partial-install','apps','sync');after=subprocess.check_output([pkg,'--json','list'],env=env);assert before==after
run('use-installed-tree',['tree','/Users/admin/pkg-live-evidence','-L','1'])
# Close heavy apps before the real catalog query.
for name in ['Obsidian','calibre']:subprocess.run(['pkill','-x',name],env=env,check=False)
P('real-cold-search','search','ripgrep',timeout=600);P('real-warm-different-search','search','jq',timeout=120)
P('list-after-search','list');P('doctor-after-search','doctor')
# Cancel a real large package download by signalling pkg only.
home=out/'cancel-home';home.mkdir(exist_ok=True);ce=dict(env,HOME=str(home),XDG_STATE_HOME=str(home/'state'),XDG_CONFIG_HOME=str(home/'config'),XDG_CACHE_HOME=str(home/'cache'));cmd=[pkg,'--verbose','install','nixpkgs:llvmPackages_21.clang'];m,s=pty.openpty();p=subprocess.Popen(cmd,env=ce,stdin=s,stdout=s,stderr=s,start_new_session=True);os.close(s);buf=b'';sent=False;deadline=time.monotonic()+180
while time.monotonic()<deadline:
 if select.select([m],[],[],.2)[0]:
  try:b=os.read(m,8192)
  except OSError:break
  if not b:break
  buf+=b;(out/'real-download-cancel.log').write_bytes(buf)
  if (b'will be fetched' in buf or b'copying path' in buf or b'building' in buf) and not sent:p.send_signal(signal.SIGINT);sent=True
 if p.poll() is not None:break
if p.poll() is None:os.killpg(p.pid,signal.SIGKILL)
rc=p.wait();os.close(m);(out/'real-download-cancel-status.json').write_text(json.dumps(dict(code=rc,signal_sent=sent,command=cmd),indent=2));run('cancelled-profile-list',[pkg,'--json','list'],e=ce)
P('final-package-set','list');P('final-health','doctor');(out/'post-done').write_text('complete\n')

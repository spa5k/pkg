#!/bin/bash
set -euo pipefail
mkdir -p /Users/admin/pkg-live-evidence
exec > >(tee /Users/admin/pkg-live-evidence/bootstrap.log) 2>&1
sw_vers
uname -m
id
df -h /
curl -fsSL https://raw.githubusercontent.com/spa5k/pkg/v0.2.0-alpha.10/install.sh -o /Users/admin/pkg-install.sh
sh /Users/admin/pkg-install.sh
/Users/admin/.local/bin/pkg --version
set +e
/Users/admin/.local/bin/pkg doctor
printf 'doctor_without_nix_exit=%s\n' "$?"
set -e
curl -fsSL https://install.determinate.systems/nix -o /Users/admin/nix-installer.sh
sh /Users/admin/nix-installer.sh install --no-confirm
zsh -lc 'command -v pkg; pkg --version; pkg doctor; pkg list'

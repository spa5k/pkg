import os,json,pathlib,subprocess,time,signal
out=pathlib.Path('/Users/admin/pkg-live-evidence');out.mkdir(exist_ok=True);logs=[];pkg='/Users/admin/.local/bin/pkg';env=dict(os.environ);env['PATH']='/Users/admin/.local/state/nix/profiles/pkg/bin:/Users/admin/.local/bin:/nix/var/nix/profiles/default/bin:'+env['PATH']
def run(label,args,timeout=300,e=None):
 t=time.monotonic()
 try:r=subprocess.run(args,env=e or env,capture_output=True,text=True,timeout=timeout,stdin=subprocess.DEVNULL);rc=r.returncode;so=r.stdout;se=r.stderr
 except FileNotFoundError as r:rc=127;so='';se=str(r)
 except subprocess.TimeoutExpired as r:rc=124;so=str(r.stdout or '');se=str(r.stderr or '')
 item=dict(label=label,args=args,code=rc,stdout=so,stderr=se,seconds=round(time.monotonic()-t,2));logs.append(item);(out/'commands.json').write_text(json.dumps(logs,indent=2));print(f'{label}: {rc} ({item["seconds"]}s)',flush=True);return item
def P(label,*args,timeout=300,e=None):return run(label,[pkg,*args],timeout,e)
def snap():return subprocess.check_output([pkg,'--json','list'],env=env)
P('fresh-doctor','doctor');P('fresh-list','list')
P('install-real-tools','install','nixpkgs:ripgrep','nixpkgs:jq','nixpkgs:hello','nixpkgs:sqlite','cask:1password-cli',timeout=600)
run('ripgrep-version',['rg','--version']);run('jq-workload',['bash','-c','printf "{\\"answer\\":42}" | jq .answer']);run('op-version',['op','--version']);run('hello',['hello'])
db=out/'user-data.sqlite';run('sqlite-user-data',['sqlite3',str(db),'create table if not exists notes(note text); insert into notes values ("survive uninstall and rollback"); select * from notes;'])
# Observe the documented partial result before one-time app storage setup.
apps=[('stats','Stats.app','Stats'),('iterm2','iTerm.app','iTerm2'),('obsidian','Obsidian.app','Obsidian'),('calibre','calibre.app','calibre')]
for token,bundle,procname in apps:
 P('info-'+token,'info','cask:'+token)
 r=P('install-'+token,'install','cask:'+token,timeout=900)
 P('list-after-'+token,'list')
 if token=='obsidian':
  P('app-storage-setup','apps','setup');P('repeat-app-storage-setup','apps','setup')
 P('sync-'+token,'apps','sync',timeout=300)
 launcher=pathlib.Path.home()/'Applications/pkg'/bundle
 if launcher.exists():
  run('open-'+token,['open','-n',str(launcher)])
  time.sleep(8)
  run('process-'+token,['pgrep','-alf',procname])
  run('screenshot-'+token,['screencapture','-x',str(out/(token+'.png'))])
 P('duplicate-'+token,'install','cask:'+token,timeout=300)
 if token=='iterm2':run('iterm-real-shell',['osascript','-e','tell application "iTerm2" to tell current window to tell current session to write text "hello; pkg list"'])
 if token=='calibre':
  run('ebook-convert-version',['ebook-convert','--version'])
  book=out/'original-book.txt';book.write_text('A real package workflow\n\nThis file was converted by the Calibre client installed with pkg.\n')
  run('ebook-conversion',['ebook-convert',str(book),str(out/'converted-book.epub')])
  run('inspect-converted-book',['unzip','-l',str(out/'converted-book.epub')])
 if token=='obsidian':run('obsidian-cli',['obsidian','--help'])
P('installed-health','doctor');P('installed-history','history');P('upgrade-everything','upgrade','--all',timeout=900)
# Exact IDs from the real native inventory.
entries=json.loads(snap())['result'];ids={x['name']:x['entry_id'] for x in entries};stats=ids.get('homebrew/cask/stats')
if stats:
 P('remove-stats-exact-id','remove',stats)
 P('other-apps-survive-stats-removal','list')
 run('remaining-launchers',['ls','-la',str(pathlib.Path.home()/'Applications/pkg')])
 P('rollback-stats','rollback',timeout=300)
 run('open-restored-stats',['open','-n',str(pathlib.Path.home()/'Applications/pkg/Stats.app')])
 run('restored-stats-process',['pgrep','-alf','Stats'])
P('remove-sqlite','remove','sqlite');P('rollback-sqlite','rollback');run('sqlite-data-after-rollback',['sqlite3',str(db),'select * from notes;'])
P('prune','prune','--older-than','1d');P('runtime-minimal-path','list',e=dict(env,PATH='/usr/bin:/bin'))
P('refuse-deprecated-cask','install','cask:chromedriver')
before=snap();P('bad-batch-all-or-nothing','install','nixpkgs:tree','nixpkgs:pkg-this-does-not-exist');print('invalid-batch-state-preserved',snap()==before,flush=True)
P('add-real-tap','tap','add','goreleaser/tap','--revision','77e442b6000587bf57e543081e95fd908b918bd7','--trust',timeout=600)
P('tap-list','tap','list');P('tap-info','info','cask:goreleaser/tap/goreleaser');P('tap-install','install','cask:goreleaser/tap/goreleaser',timeout=600);run('goreleaser-version',['goreleaser','--version'])
# Concurrent real Nixpkgs requests, away from the main app profile.
trials=[]
for i in range(5):
 state=out/f'race-{i}';home=out/f'race-home-{i}';home.mkdir(exist_ok=True);e=dict(env,HOME=str(home),XDG_STATE_HOME=str(state),XDG_CONFIG_HOME=str(home/'.config'),XDG_CACHE_HOME=str(home/'.cache'));refs=['github:NixOS/nixpkgs/567a49d1913ce81ac6e9582e3553dd90a955875f#'+n for n in ['hello','jq']]
 cmds=[[pkg,'install',r] for r in refs];procs=[subprocess.Popen(c,env=e,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE) for c in cmds];res=[]
 for c,p in zip(cmds,procs):
  so,se=p.communicate(timeout=180);res.append(dict(command=c,code=p.returncode,stdout=so,stderr=se))
 r=P('race-'+str(i)+'-list','--json','list',e=e);installed=json.loads(r['stdout'])['result'] if r['code']==0 else None;trials.append(dict(index=i,commands=res,installed=installed,lost_change=all(r['code']==0 for r in res) and len(installed)!=2));(out/'concurrency.json').write_text(json.dumps(trials,indent=2))
print('mac-races-lost',sum(r['lost_change'] for r in trials),flush=True)
P('restore-main-app-launchers','apps','sync',timeout=300);P('final-doctor','doctor')
(out/'done').write_text('core workflows complete\n')

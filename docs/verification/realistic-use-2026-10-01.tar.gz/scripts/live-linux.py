import json,os,pathlib,subprocess,time,pty,select,signal
out=pathlib.Path('/home/user/pkg-test-evidence/live');out.mkdir(parents=True,exist_ok=True);logs=[];pkg=str(pathlib.Path.home()/'.local/bin/pkg');env=dict(os.environ);env['PATH']=str(pathlib.Path.home()/'.local/state/nix/profiles/pkg/bin')+':'+str(pathlib.Path.home()/'.local/bin')+':'+env['PATH']
def run(label,args,timeout=300,e=None):
 t=time.monotonic()
 try:r=subprocess.run(args,env=e or env,capture_output=True,text=True,timeout=timeout,stdin=subprocess.DEVNULL);rc=r.returncode;so=r.stdout;se=r.stderr
 except FileNotFoundError as r:rc=127;so='';se=str(r)
 except subprocess.TimeoutExpired as r:rc=124;so=str(r.stdout or '');se=str(r.stderr or '')
 item=dict(label=label,args=args,code=rc,stdout=so,stderr=se,seconds=round(time.monotonic()-t,2));logs.append(item);(out/'commands.json').write_text(json.dumps(logs,indent=2));print(f'{label}: {rc} ({item["seconds"]}s)',flush=True);return item
def P(label,*args,timeout=300,e=None):return run(label,[pkg,*args],timeout,e)
def snap():return subprocess.check_output([pkg,'--json','list'],env=env)
P('initial-real-tools','install','nixpkgs:ripgrep','nixpkgs:jq','nixpkgs:fd','nixpkgs:hello','cask:1password-cli')
for name in ['ripgrep','jq','fd','hello']:
 P('reinstall-'+name,'install','nixpkgs:'+name)
P('exact-nested-info','info','nixpkgs:python312Packages.pip')
P('install-python-and-git','install','nixpkgs:python312','nixpkgs:git')
run('use-python-json',['python3.12','-c','import json,hashlib;print(json.dumps({"sha256":hashlib.sha256(b"real-workload").hexdigest()}))'])
repo=out/'scratch-git';repo.mkdir(exist_ok=True)
run('use-git-init',['git','init',str(repo)])
run('use-git-status',['git','-C',str(repo),'status','--short'])
before=snap();P('conflicting-python-version','install','nixpkgs:python313');print('python-conflict-state-preserved',before==snap(),flush=True)
before=snap();P('invalid-batch-all-or-nothing','install','nixpkgs:tree','nixpkgs:this-package-does-not-exist-pkg-real-check');print('invalid-batch-state-preserved',before==snap(),flush=True)
P('excluded-macos-app-on-linux','install','cask:obsidian')
P('excluded-deprecated-cask','install','cask:chromedriver')
P('install-raw-vendor-binary','install','cask:sentry-cli')
run('use-sentry-cli',['sentry-cli','--version'])
P('install-electron-appimage','install','cask:actual',timeout=600)
run('run-appimage-node',['Actual','-e','console.log(JSON.stringify({electron:process.versions.electron,node:process.versions.node}));'],e=dict(env,ELECTRON_RUN_AS_NODE='1'))
P('list-installed','list');P('upgrade-existing','upgrade','--all',timeout=600);P('history','history');P('doctor','doctor')
P('remove-hello','remove','hello');run('hello-absent',['bash','-c','command -v hello'])
P('rollback-hello','rollback');run('hello-restored',['hello'])
P('prune-old-only','prune','--older-than','1d');run('hello-after-prune',['hello'])
P('fixed-reference-install','install','github:NixOS/nixpkgs/567a49d1913ce81ac6e9582e3553dd90a955875f#tree')
P('fixed-reference-upgrade','upgrade','--all',timeout=600);run('tree-workload',['tree',str(repo)])
P('minimal-path-runtime-discovery','list',e=dict(env,PATH='/usr/bin:/bin'))
# Concurrent real package installs in independent native profiles.
trials=[]
for lane in ['pkg','nix']:
 for index in range(10 if lane=='pkg' else 3):
  state=out/f'race-{lane}-{index}';profile=state/'nix/profiles/pkg';e=dict(env,XDG_STATE_HOME=str(state))
  refs=['github:NixOS/nixpkgs/567a49d1913ce81ac6e9582e3553dd90a955875f#'+n for n in ['hello','jq']]
  commands=[[pkg,'install',ref] if lane=='pkg' else ['nix','profile','install','--profile',str(profile),ref] for ref in refs]
  procs=[subprocess.Popen(c,env=e,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE) for c in commands];res=[]
  for c,p in zip(commands,procs):
   so,se=p.communicate(timeout=180);res.append(dict(command=c,code=p.returncode,stdout=so,stderr=se))
  r=P(f'race-{lane}-{index}-list','--json','list',e=e);installed=json.loads(r['stdout'])['result'] if r['code']==0 else None
  trials.append(dict(lane=lane,index=index,commands=res,installed=installed,lost_change=all(r['code']==0 for r in res) and len(installed)!=2));(out/'concurrency.json').write_text(json.dumps(trials,indent=2))
 print('race-lane',lane,'lost',sum(x['lost_change'] for x in trials if x['lane']==lane),flush=True)
# Actual interactive setup with consent in this disposable Linux machine.
cmd=[pkg,'tap','add','goreleaser/tap','--revision','77e442b6000587bf57e543081e95fd908b918bd7','--trust'];m,s=pty.openpty();child=subprocess.Popen(cmd,env=env,stdin=s,stdout=s,stderr=s,start_new_session=True);os.close(s);buf=b'';sent=False;deadline=time.monotonic()+600
while time.monotonic()<deadline:
 if select.select([m],[],[],.2)[0]:
  try:chunk=os.read(m,8192)
  except OSError:break
  if not chunk:break
  buf+=chunk
  if b'apply now? [y/N]' in buf and not sent:os.write(m,b'y\n');sent=True
  (out/'tap-interactive.log').write_bytes(buf)
 if child.poll() is not None:break
if child.poll() is None:os.killpg(child.pid,signal.SIGKILL)
rc=child.wait();os.close(m);logs.append(dict(label='interactive-tap-setup',args=cmd,code=rc,stdout=buf.decode(errors='replace'),setup_answered=sent));(out/'commands.json').write_text(json.dumps(logs,indent=2));print('interactive-tap-setup',rc,flush=True)
(out/'done').write_text('complete\n')

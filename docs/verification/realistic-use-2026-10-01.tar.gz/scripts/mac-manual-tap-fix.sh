#!/bin/bash
set -euo pipefail
cp /etc/nix/nix.custom.conf /Users/admin/pkg-live-evidence/nix.custom.before-manual.txt
printf '%s\n' 'sandbox-paths = /System/Library/Frameworks /System/Library/PrivateFrameworks /bin/bash /bin/sh /usr/lib' | sudo tee -a /etc/nix/nix.custom.conf
sudo launchctl kickstart -k system/systems.determinate.nix-daemon
/nix/var/nix/profiles/default/bin/nix config show sandbox-paths
/Users/admin/.local/state/nix/profiles/pkg/bin/sqlite3 /Users/admin/pkg-live-evidence/user-data.sqlite "INSERT INTO notes VALUES('survive uninstall and rollback'); SELECT * FROM notes;"

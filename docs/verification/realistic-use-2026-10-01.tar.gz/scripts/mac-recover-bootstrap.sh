#!/bin/bash
set -euo pipefail
exec > >(tee /Users/admin/pkg-live-evidence/client-after-nix.log) 2>&1
SHELL=/bin/zsh sh /Users/admin/pkg-install.sh
/bin/zsh -ilc 'command -v pkg; command -v nix; pkg --version; pkg doctor; pkg list'

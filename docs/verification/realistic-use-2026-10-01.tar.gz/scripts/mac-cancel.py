import pathlib,os,json,subprocess,time,signal
out=pathlib.Path('/Users/admin/pkg-live-evidence');pkg='/Users/admin/.local/bin/pkg';env=dict(os.environ,PATH='/Users/admin/.local/state/nix/profiles/pkg/bin:/Users/admin/.local/bin:/nix/var/nix/profiles/default/bin:/usr/bin:/bin:/usr/sbin:/sbin');rows=[]
def run(label,args,e=env,timeout=300):
 t=time.monotonic();p=subprocess.Popen(args,env=e,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
 try:so,se=p.communicate(timeout=timeout)
 except subprocess.TimeoutExpired:
  os.killpg(p.pid,signal.SIGTERM);so,se=p.communicate(timeout=20)
 x=dict(label=label,args=args,code=p.returncode,stdout=so,stderr=se,seconds=round(time.monotonic()-t,2));rows.append(x);(out/'extra-commands.json').write_text(json.dumps(rows,indent=2));print(label,x['code'],flush=True);return x
# Start a genuinely uncached vendor download and cancel pkg itself.
home=out/'cancel-code-home';home.mkdir(exist_ok=True);e=dict(env,HOME=str(home),XDG_STATE_HOME=str(home/'state'),XDG_CONFIG_HOME=str(home/'config'),XDG_CACHE_HOME=str(home/'cache'));log=open(out/'cancel-code.log','w');p=subprocess.Popen([pkg,'--verbose','install','cask:visual-studio-code'],env=e,stdout=log,stderr=log,start_new_session=True);t=time.monotonic();observed='';sent=False
while p.poll() is None and time.monotonic()-t<180:
 text=subprocess.check_output(['ps','-axo','pid,ppid,comm'],text=True)
 curls=[line for line in text.splitlines() if '/nix/store/' in line and '/curl' in line]
 if curls:
  observed='\n'.join(curls);p.send_signal(signal.SIGINT);sent=True;break
 time.sleep(.25)
try:rc=p.wait(timeout=30)
except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);rc=p.wait()
log.close();(out/'cancel-code-status.json').write_text(json.dumps(dict(code=rc,signal_sent=sent,observed_curl=observed,seconds=round(time.monotonic()-t,2)),indent=2));print('cancel-vendor',rc,sent,flush=True)
run('cancelled-vendor-profile',[pkg,'--json','list'],e)
run('health-after-vendor-cancel',[pkg,'doctor']);(out/'cancel-done').write_text('complete\n')

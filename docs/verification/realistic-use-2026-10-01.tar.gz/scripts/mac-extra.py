import pathlib,os,json,subprocess,time,signal
out=pathlib.Path('/Users/admin/pkg-live-evidence');pkg='/Users/admin/.local/bin/pkg';env=dict(os.environ,PATH='/Users/admin/.local/state/nix/profiles/pkg/bin:/Users/admin/.local/bin:/nix/var/nix/profiles/default/bin:/usr/bin:/bin:/usr/sbin:/sbin');rows=[]
def run(label,args,e=env,timeout=300):
 t=time.monotonic();p=subprocess.Popen(args,env=e,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
 try:so,se=p.communicate(timeout=timeout)
 except subprocess.TimeoutExpired:
  os.killpg(p.pid,signal.SIGTERM);so,se=p.communicate(timeout=20)
 x=dict(label=label,args=args,code=p.returncode,stdout=so,stderr=se,seconds=round(time.monotonic()-t,2));rows.append(x);(out/'extra-commands.json').write_text(json.dumps(rows,indent=2));print(label,x['code'],flush=True);return x
home=pathlib.Path('/Users/admin/calibre-only');home.mkdir(exist_ok=True);ce=dict(env,HOME=str(home),XDG_STATE_HOME=str(home/'state'),XDG_CONFIG_HOME=str(home/'config'),XDG_CACHE_HOME=str(home/'cache'))
r=run('calibre-in-isolated-profile',[pkg,'install','cask:calibre'],ce,600)
if r['code']==0:
 data=(home/'Applications/pkg/.pkg-launcher-sources').read_text();(out/'calibre-launcher-sources.tsv').write_text(data)
 name,source=data.strip().split('\t',1);store=source.split('/libexec/pkg/app-sources/')[0];actual='/nix/var/pkg/cask-apps/501/'+pathlib.Path(store).name+'/'+name
 run('calibre-vendor-signature',['codesign','--verify','--deep','--strict',actual]);run('open-calibre',['open','-n',str(home/'Applications/pkg'/name)])
 cli=actual+'/Contents/MacOS/ebook-convert';run('calibre-converter-version',[cli,'--version'])
 book=out/'original-book.txt';book.write_text('A real package workflow\n\nThis book was converted by the Calibre app installed with pkg.\n')
 run('calibre-convert-real-file',[cli,str(book),str(out/'converted-book.epub')],timeout=180);run('inspect-real-epub',['unzip','-l',str(out/'converted-book.epub')])
 time.sleep(5);run('screenshot-calibre',['screencapture','-x',str(out/'calibre.png')])
# Start a genuinely uncached vendor download and cancel pkg itself.
home=out/'cancel-vendor-home';home.mkdir(exist_ok=True);e=dict(env,HOME=str(home),XDG_STATE_HOME=str(home/'state'),XDG_CONFIG_HOME=str(home/'config'),XDG_CACHE_HOME=str(home/'cache'));log=open(out/'cancel-vendor.log','w');p=subprocess.Popen([pkg,'--verbose','install','cask:blender'],env=e,stdout=log,stderr=log,start_new_session=True);t=time.monotonic();observed='';sent=False
while p.poll() is None and time.monotonic()-t<180:
 text=subprocess.check_output(['ps','-axo','pid,ppid,comm'],text=True)
 curls=[line for line in text.splitlines() if '/nix/store/' in line and '/curl' in line]
 if curls:
  observed='\n'.join(curls);p.send_signal(signal.SIGINT);sent=True;break
 time.sleep(.25)
try:rc=p.wait(timeout=30)
except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);rc=p.wait()
log.close();(out/'cancel-vendor-status.json').write_text(json.dumps(dict(code=rc,signal_sent=sent,observed_curl=observed,seconds=round(time.monotonic()-t,2)),indent=2));print('cancel-vendor',rc,sent,flush=True)
run('cancelled-vendor-profile',[pkg,'--json','list'],e)
run('health-after-vendor-cancel',[pkg,'doctor']);(out/'extra-done').write_text('complete\n')

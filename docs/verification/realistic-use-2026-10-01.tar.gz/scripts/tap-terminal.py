import os,subprocess,pathlib,pty,select,time,signal
out=pathlib.Path('/Users/admin/pkg-live-evidence');out.mkdir(exist_ok=True);env=dict(os.environ);env['PATH']='/Users/admin/.local/bin:/nix/var/nix/profiles/default/bin:'+env['PATH'];cmd=['/Users/admin/.local/bin/pkg','tap','add','goreleaser/tap','--revision','77e442b6000587bf57e543081e95fd908b918bd7','--trust']
m,s=pty.openpty();p=subprocess.Popen(cmd,env=env,stdin=s,stdout=s,stderr=s,start_new_session=True);os.close(s);buf=b'';answered=False;deadline=time.monotonic()+900
while time.monotonic()<deadline:
 if select.select([m],[],[],.2)[0]:
  try:b=os.read(m,8192)
  except OSError:break
  if not b:break
  buf+=b;(out/'tap-terminal.log').write_bytes(buf)
  if b'apply now? [y/N]' in buf and not answered:os.write(m,b'y\n');answered=True
 if p.poll() is not None:break
if p.poll() is None:os.killpg(p.pid,signal.SIGKILL)
code=p.wait();os.close(m);print(buf.decode(errors='replace'));print('tap-terminal-exit',code);(out/'tap-terminal-status.txt').write_text(str(code))

# Real-app audit: results so far

Started: 2026-09-30T16:38:28Z
Runner PID: 8047

## Batch 1 tokens (cycle: info/install/verify/dup/list/remove/empty):

- duplicacy-cli: install_rc=1, dup_unchanged=None, final_empty=None
- sentry-cli: install_rc=1, dup_unchanged=None, final_empty=None
- claude-code: install_rc=1, dup_unchanged=None, final_empty=None
- 1password-cli: install_rc=1, dup_unchanged=None, final_empty=None
- trunk-io: install_rc=1, dup_unchanged=None, final_empty=None
- notion-cli: install_rc=1, dup_unchanged=None, final_empty=None
- wizcli: install_rc=1, dup_unchanged=None, final_empty=None
- devtunnel: install_rc=1, dup_unchanged=None, final_empty=None
- grok-build: install_rc=1, dup_unchanged=None, final_empty=None
- mend: install_rc=1, dup_unchanged=None, final_empty=None
- unity-cli: install_rc=1, dup_unchanged=None, final_empty=None
- android-cli: install_rc=1, dup_unchanged=None, final_empty=None
- koreader: install_rc=1, dup_unchanged=None, final_empty=None
- localsend: install_rc=1, dup_unchanged=None, final_empty=None
- kitty: install_rc=1, dup_unchanged=None, final_empty=None
- codex: install_rc=1, dup_unchanged=None, final_empty=None
- confluent-cli: install_rc=1, dup_unchanged=None, final_empty=None
- slack-cli: install_rc=1, dup_unchanged=None, final_empty=None
- subgit: install_rc=1, dup_unchanged=None, final_empty=None
- liquibase-community: install_rc=1, dup_unchanged=None, final_empty=None

## Scenarios:
- co_install: {"both_present": null, "b_preserved": false, "rollback_restored_a": false}
- conflicting_binary: {"atomic_no_mutation": null}
- valid_plus_missing: {"atomic_fail_no_mutation": null, "mend_not_installed": false}

Finished: 2026-09-30T16:39:00Z

#!/usr/bin/env python3
"""Real-app Linux cask execution audit for pkg CLI.

Iterates 8 real eligible casks against the release pkg binary using a
dedicated native profile. Incremental results.json, per-command logs,
profile-manifest snapshots around failures, then co-install/rollback/
conflict/atomicity scenarios, then diagnostics. Fixture packages are
never counted as real casks.
"""
import json
import os
import re
import shutil
import subprocess
import sys
import time

AUDIT = "/home/user/real-app-audit"
PKG = "/home/user/workspace/target/release/pkg"
CASKS = "path:/home/user/workspace/nix/casks"
PROFILE = f"{AUDIT}/state/nix/profiles/pkg"
LOGS = f"{AUDIT}/logs"
RESULTS = f"{AUDIT}/results.json"
PROGRESS = f"{AUDIT}/progress.json"
RUNNER_PID = f"{AUDIT}/runner.pid"
REPORT = f"{AUDIT}/model-report.md"

FIRST_BATCH = [
    "duplicacy-cli", "sentry-cli", "claude-code", "1password-cli",
    "trunk-io", "notion-cli", "wizcli", "devtunnel",
]
SUBSTITUTES = [
    "grok-build", "mend", "unity-cli", "android-cli",
    "koreader", "localsend", "kitty", "codex",
    "confluent-cli", "slack-cli", "subgit", "liquibase-community",
]
# GUI-capable tokens (attempt xvfb launch, non-fatal)
GUI_TOKENS = {"kitty", "koreader", "localsend"}

NIX_COMMON = [
    "--extra-experimental-features", "nix-command flakes",
    "--option", "accept-flake-config", "false",
    "--option", "allow-import-from-derivation", "false",
]


def sanitized_env():
    home = f"{AUDIT}/home"
    os.makedirs(home, exist_ok=True)
    os.makedirs(f"{home}/.local/share", exist_ok=True)
    os.makedirs(f"{AUDIT}/run", exist_ok=True)
    env = {
        "PATH": "/usr/bin:/bin:/usr/local/bin:/nix/var/nix/profiles/default/bin:"
                "/home/user/.nix-profile/bin",
        "HOME": home,
        "LANG": "C.UTF-8",
        "LC_ALL": "C.UTF-8",
        "TERM": "dumb",
        "XDG_DATA_HOME": f"{home}/.local/share",
        "XDG_CONFIG_HOME": f"{home}/.config",
        "XDG_CACHE_HOME": f"{AUDIT}/cache/xdg",
        "XDG_RUNTIME_DIR": f"{AUDIT}/run",
        "NIX_CONFIG": "extra-experimental-features = nix-command flakes",
        "SSL_CERT_FILE": "/etc/ssl/certs/ca-certificates.crt",
    }
    os.makedirs(env["XDG_CONFIG_HOME"], exist_ok=True)
    os.makedirs(env["XDG_CACHE_HOME"], exist_ok=True)
    return env


ENV = sanitized_env()
RESULTS_DATA = {"started": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                "tokens": {}, "scenarios": {}, "diagnostics": None,
                "finished": None}


def log_path(name):
    safe = re.sub(r"[^A-Za-z0-9._@-]", "_", name)
    return f"{LOGS}/{safe}.log"


def save_results():
    tmp = RESULTS + ".tmp"
    with open(tmp, "w") as f:
        json.dump(RESULTS_DATA, f, indent=2)
    os.replace(tmp, RESULTS)


def save_progress(stage, detail=""):
    p = {"pid": os.getpid(), "stage": stage, "detail": detail,
         "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
    tmp = PROGRESS + ".tmp"
    with open(tmp, "w") as f:
        json.dump(p, f)
    os.replace(tmp, PROGRESS)


def run(cmd, timeout, logfile, cwd=AUDIT):
    """Run cmd with sanitized env, tee output to logfile, return record."""
    rec = {"cmd": cmd if isinstance(cmd, str) else " ".join(cmd[:8]) + (" ..." if isinstance(cmd, list) and len(cmd) > 8 else ""),
           "timeout": timeout}
    t0 = time.time()
    with open(logfile, "ab") as lf:
        lf.write(f"\n$ {' '.join(cmd) if isinstance(cmd, list) else cmd}\n".encode())
        lf.flush()
        try:
            p = subprocess.run(cmd, cwd=cwd, env=ENV, stdin=subprocess.DEVNULL,
                               stdout=lf, stderr=subprocess.STDOUT, timeout=timeout)
            rec.update(returncode=p.returncode, seconds=round(time.time() - t0, 1))
        except subprocess.TimeoutExpired:
            rec.update(returncode="TIMEOUT", seconds=round(time.time() - t0, 1))
        except FileNotFoundError as e:
            rec.update(returncode="ENOENT", error=str(e), seconds=0)
    return rec


def pkg_run(args, timeout=600, tag=None):
    name = "pkg-" + (tag or "-".join(a for a in args if not a.startswith("-") and "/" not in a)[:6])
    rec = run([PKG] + args, timeout, log_path(name))
    return rec


def nix_profile_list():
    """Return parsed profile manifest (nix profile list --json)."""
    rec = run(["nix"] + NIX_COMMON + ["profile", "list", "--profile", PROFILE,
                                      "--json"], 120, log_path("nix-profile-list-probe"))
    if rec["returncode"] == 0:
        try:
            with open(log_path("nix-profile-list-probe"), "rb") as f:
                txt = f.read().decode("utf-8", "replace")
                start = txt.find("{")
                return json.loads(txt[start:txt.rfind("}") + 1]), rec
        except Exception:
            return None, rec
    return None, rec


def snapshot_manifest(tag):
    man, _ = nix_profile_list()
    if man is not None:
        entries = {}
        for k, v in (man.get("elements") or man.get("entries") or {}).items():
            entries[k] = {kk: v.get(kk) for kk in
                          ("active", "store-path", "original-uri", "attr-path")}
        path = f"{AUDIT}/state/manifest-{tag}.json"
        with open(path, "w") as f:
            json.dump(entries, f, indent=2)
        return entries
    return None


def manifests_equal(a, b):
    if a is None or b is None:
        return None
    return {k: v for k, v in a.items()} == {k: v for k, v in b.items()}


def verify_exec(token, exe_name):
    """Run installed binary --version or --help under sanitized env."""
    candidates = [f"{PROFILE}/bin/{exe_name}"]
    found = next((c for c in candidates if os.path.exists(c)), None)
    if not found:
        return {"found": False, "checked": candidates}
    vrec = run([found, "--version"], 120, log_path(f"exec-{exe_name}-version"))
    if vrec["returncode"] not in (0,):
        vrec2 = run([found, "--help"], 120, log_path(f"exec-{exe_name}-help"))
        vrec["help_fallback"] = vrec2
        vrec["returncode"] = vrec2["returncode"] if vrec2["returncode"] == 0 else vrec["returncode"]
    return {"found": True, "path": found, "version_run": vrec}


def list_entry(token):
    rec = pkg_run(["--json", "list"], 120, tag=f"list-{token}")
    entry = None
    if rec["returncode"] == 0:
        try:
            with open(log_path(f"pkg-list-{token}.log"), "rb") as f:
                txt = f.read().decode("utf-8", "replace")
                dec = json.JSONDecoder()
                idx = txt.find("{")
                if idx >= 0:
                    obj, _ = dec.raw_decode(txt[idx:])
                    items = obj if isinstance(obj, list) else obj.get("entries") or obj.get("items") or []
                    entry = next((e for e in items if token in json.dumps(e)), items if isinstance(items, list) and len(items) == 1 else None)
        except Exception as e:
            entry = f"parse-error: {e}"
    rec["exact_entry_match"] = (isinstance(entry, (dict, list)) and
                                json.dumps(entry) != "[]")
    return rec


def gui_launch(token, exe_name):
    """Attempt real GUI startup under Xvfb when feasible."""
    if token not in GUI_TOKENS or not shutil.which("xvfb-run"):
        return {"attempted": False, "reason": "non-gui or no xvfb"}
    exe = f"{PROFILE}/bin/{exe_name}"
    if not os.path.exists(exe):
        return {"attempted": False, "reason": "no exe"}
    rec = run(["xvfb-run", "-a", "-n", "77", exe], 90, log_path(f"gui-{token}"))
    return {"attempted": True, "run": rec,
            "note": "nonzero rc may be expected if app exits on its own"}


def full_cycle(token):
    """info / install / verify / duplicate install / list / remove / empty."""
    t = {"token": token, "steps": {}}
    save_progress("batch1", token)

    t["steps"]["info"] = pkg_run(["info", f"cask:{token}"], 180, tag=f"info-{token}")
    t["steps"]["install"] = pkg_run(["install", f"cask:{token}"], 600, tag=f"install-{token}")

    if t["steps"]["install"]["returncode"] == 0:
        exe = token.replace("-cli", "").replace("@", "-at-")
        # token -> typical binary name mapping for our picks
        binmap = {"duplicacy-cli": "duplicacy", "sentry-cli": "sentry-cli",
                  "claude-code": "claude", "1password-cli": "op",
                  "trunk-io": "trunk", "notion-cli": "ntn", "wizcli": "wizcli",
                  "devtunnel": "devtunnel", "grok-build": "grok",
                  "mend": "mend", "unity-cli": "unity", "android-cli": "android",
                  "koreader": "koreader", "localsend": "localsend_app",
                  "kitty": "kitty", "codex": "codex",
                  "confluent-cli": "confluent", "slack-cli": "slack",
                  "subgit": "subgit", "liquibase-community": "liquibase"}
        exe = binmap.get(token, token)
        t["steps"]["exec_verify"] = verify_exec(token, exe)
        t["steps"]["gui"] = gui_launch(token, exe)

        man_before = snapshot_manifest("dup-" + token + "-before")
        t["steps"]["duplicate_install"] = pkg_run(["install", f"cask:{token}"], 600,
                                                  tag=f"dup-{token}")
        man_after = snapshot_manifest("dup-" + token + "-after")
        t["steps"]["duplicate_unchanged_manifest"] = manifests_equal(man_before, man_after)

        t["steps"]["list"] = list_entry(token)
        t["steps"]["remove"] = pkg_run(["remove", f"cask:{token}"], 600, tag=f"remove-{token}")
        t["steps"]["final_list"] = pkg_run(["--json", "list"], 120, tag=f"final-{token}")
        # prove final empty: parse list output for zero entries
        empty = None
        try:
            with open(log_path(f"pkg-final-{token}.log"), "rb") as f:
                txt = f.read().decode("utf-8", "replace")
                idx = txt.find("{")
                if txt.strip().endswith("[]") or '"entries": []' in txt or '"items": []' in txt:
                    empty = True
                elif idx >= 0:
                    obj = json.loads(txt[idx:txt.rfind("}") + 1])
                    items = obj if isinstance(obj, list) else obj.get("entries") or obj.get("items") or []
                    empty = len(items) == 0
        except Exception:
            empty = None
        t["steps"]["final_empty"] = empty
    else:
        # failure path: snapshot before/after to prove no partial mutation
        man_before = snapshot_manifest("fail-" + token + "-before")
        t["steps"]["post_fail_manifest"] = man_before
        t["failure_manifest_captured"] = True

    RESULTS_DATA["tokens"][token] = t
    save_results()
    return t


def scenario_co_install():
    save_progress("scenario", "co-install")
    s = {}
    a, b = "duplicacy-cli", "trunk-io"
    s["install_a"] = pkg_run(["install", f"cask:{a}"], 600, tag="co-a")
    s["install_b"] = pkg_run(["install", f"cask:{b}"], 600, tag="co-b")
    man = snapshot_manifest("co-both")
    s["both_present"] = sorted(man.keys()) if man else None
    s["remove_a"] = pkg_run(["remove", f"cask:{a}"], 600, tag="co-rm-a")
    man_after = snapshot_manifest("co-after-rm-a")
    s["b_preserved"] = (man_after is not None and any("trunk" in k for k in man_after))
    # rollback restores removed package a
    s["history"] = pkg_run(["history"], 120, tag="co-history")
    s["rollback"] = pkg_run(["rollback"], 600, tag="co-rollback")
    man_rb = snapshot_manifest("co-after-rollback")
    s["rollback_restored_a"] = (man_rb is not None and any("duplicacy" in k for k in man_rb))
    # cleanup both for later scenarios
    for tok in (a, b):
        pkg_run(["remove", f"cask:{tok}"], 600, tag=f"co-clean-{tok}")
    RESULTS_DATA["scenarios"]["co_install"] = s
    save_results()


def scenario_conflict():
    save_progress("scenario", "conflicting-binary")
    s = {}
    # claude-code provides `claude`; claude-code@latest also provides `claude`.
    s["install_first"] = pkg_run(["install", "cask:claude-code"], 600, tag="conf-1st")
    man_before = snapshot_manifest("conf-before")
    s["install_conflicting"] = pkg_run(["install", "cask:claude-code@latest"], 600, tag="conf-2nd")
    man_after = snapshot_manifest("conf-after")
    s["atomic_no_mutation"] = manifests_equal(man_before, man_after)
    # cleanup
    s["cleanup"] = pkg_run(["remove", "cask:claude-code"], 600, tag="conf-clean")
    RESULTS_DATA["scenarios"]["conflicting_binary"] = s
    save_results()


def scenario_valid_plus_missing():
    save_progress("scenario", "valid+missing-atomic")
    s = {}
    man_before = snapshot_manifest("vm-before")
    s["install"] = pkg_run(["install", "cask:mend", "cask:no-such-token-xyz-999"],
                           600, tag="vm")
    man_after = snapshot_manifest("vm-after")
    s["atomic_fail_no_mutation"] = manifests_equal(man_before, man_after)
    s["mend_not_installed"] = man_after is not None and not any("mend" in k for k in man_after)
    RESULTS_DATA["scenarios"]["valid_plus_missing"] = s
    save_results()


def diagnostics():
    save_progress("diagnostics")
    d = {}
    d["doctor"] = pkg_run(["doctor"], 300, tag="doctor")
    d["doctor_json"] = pkg_run(["--json", "doctor"], 300, tag="doctor-json")
    RESULTS_DATA["diagnostics"] = d
    save_results()


def write_report():
    done = list(RESULTS_DATA["tokens"].keys())
    lines = ["# Real-app audit: results so far", "",
             f"Started: {RESULTS_DATA['started']}",
             f"Runner PID: {os.getpid()}", "",
             "## Batch 1 tokens (cycle: info/install/verify/dup/list/remove/empty):", ""]
    for tok, t in RESULTS_DATA["tokens"].items():
        steps = t.get("steps", {})
        ok = steps.get("install", {}).get("returncode")
        empty = steps.get("final_empty")
        dup = t.get("steps", {}).get("duplicate_unchanged_manifest")
        lines.append(f"- {tok}: install_rc={ok}, dup_unchanged={dup}, final_empty={empty}")
    lines += ["", "## Scenarios:"]
    for k, v in RESULTS_DATA.get("scenarios", {}).items():
        lines.append(f"- {k}: {json.dumps({kk: vv for kk, vv in v.items() if not isinstance(vv, dict)}, default=str)}")
    lines += ["", f"Finished: {RESULTS_DATA.get('finished')}", ""]
    with open(REPORT, "w") as f:
        f.write("\n".join(lines))


def main():
    os.makedirs(LOGS, exist_ok=True)
    with open(RUNNER_PID, "w") as f:
        f.write(str(os.getpid()))
    save_progress("start")
    save_results()

    queue = list(FIRST_BATCH) + list(SUBSTITUTES)
    completed = []
    for tok in queue:
        if len(completed) >= 8:
            break
        save_progress("batch1", f"{tok} ({len(completed) + 1}/8)")
        try:
            t = full_cycle(tok)
            if t["steps"].get("install", {}).get("returncode") == 0 or \
               t["steps"].get("info", {}).get("returncode") == 0:
                completed.append(tok)
            else:
                RESULTS_DATA.setdefault("skipped", []).append(tok)
                save_results()
        except Exception as e:
            RESULTS_DATA.setdefault("errors", []).append({"token": tok, "error": str(e)})
            snapshot_manifest("crash-" + tok)
            save_results()

    # scenarios on real casks only
    try:
        scenario_co_install()
    except Exception as e:
        RESULTS_DATA.setdefault("errors", []).append({"scenario": "co_install", "error": str(e)})
        save_results()
    try:
        scenario_conflict()
    except Exception as e:
        RESULTS_DATA.setdefault("errors", []).append({"scenario": "conflict", "error": str(e)})
        save_results()
    try:
        scenario_valid_plus_missing()
    except Exception as e:
        RESULTS_DATA.setdefault("errors", []).append({"scenario": "valid+missing", "error": str(e)})
        save_results()

    try:
        diagnostics()
    except Exception as e:
        RESULTS_DATA.setdefault("errors", []).append({"scenario": "diagnostics", "error": str(e)})

    RESULTS_DATA["finished"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    RESULTS_DATA["completed_real_casks"] = completed
    save_results()
    write_report()
    save_progress("done")


if __name__ == "__main__":
    main()

# Parent classification of GLM review

GLM-5.3 ran through Pi with provider `zai`. Its raw review is evidence, not the final defect classification.

- `casks` is a valid exact native element ID. Removing that ID with other elements present must remove that one element and keep the others. It is not an ambiguous package alias. The old runner left duplicates, then removed one exact entry. That result does not establish a product removal bug. The repeat starts from an empty isolated profile and uses the ID returned by `pkg --json list`.
- Startup matching uses the canonical installed executable path. If that executable fails while the same vendor app in a mutable control copy starts, this can establish an installation regression. If both fail, vendor or VM behavior needs investigation. The raw GLM review inverted this condition.
- A cancelled Nix realization can leave downloads or store outputs in the shared cache. Profile atomicity concerns the authoritative profile and active entries. An unchanged store-object count is not a valid requirement.
- The first VM's host-disk exhaustion and resulting read errors invalidate its late tests. It was stopped and deleted. The fresh VM uses the exact reviewed source, corrected native manifest parsing, canonical process paths, and checked exact IDs. Its completed tests have empty profiles after removal.
- Extra checks use only real casks and a real Nixpkgs hello package. No mock or fixture counts toward the 15-app requirement. Edge checks verify real binary conflicts, exact survivor entries, restored vendor processes, valid-plus-missing refusal, and observed native work before cancellation.

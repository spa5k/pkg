# GLM-5.3 reviewer feedback — pkg real-app audit, retry VM (2026-09-30)

Inputs reviewed: host `mac-retry-runner.py` (+diff vs mac-runner-current/mac-verified), `mac-first-results.json`, old trace `local-glm-mac.jsonl` (entry_id semantics), one guest snapshot via `tart exec` (progress + results).

## Guest snapshot (single read, 17:16:49)
Runner PID 798 alive (6m42s), iina in progress (7/15), attention=[]. Disk 53Gi free.
Completed 6 (stats, raycast, rectangle, alt-tab, maccy, appcleaner): install=0, **startup=pass**, remove=0, launcher_removed=true, profile_empty=true, tree_compare **equal (0 missing/extra/content/symlink diffs)**. Duplicate-install manifest byte-identical. Parent corrections (native v3 manifest parse, comm-based process match, realpath canonical store paths, koly DMG detection) verified working — first-run false startup/removal failures are gone.

## Runner bugs (remaining, in running mac-retry-runner.py)
1. **Exception mid-`do_install` skips removal**: main() catches the exception but never removes the just-installed app (first-run cursor: Errno 92 → cursor stayed installed, polluted every later check). No try/finally around the install→remove span. If any of the following throws, the same leak recurs:
   - `res["info"]` does `json.loads(out(r))` with the **default 4000-char cap** — truncated info JSON ⇒ JSONDecodeError.
   - `manifest_state()` asserts `version == 3`; `native_store_pairs()` assumes `attrPath`/`storePaths` keys; `find_vendor_process` uses `check_output` (raises if ps fails).
2. **`edge_co_install` fallback `entry_id_for(...) or "casks"`**: on lookup failure it silently removes by the ambiguous alias — the exact first-run failure mode. Should hard-fail the edge instead. Also `remove_stats` records only exit code; doesn't verify via `pkg list` that stats is actually gone before judging the survivors.
3. **`edge_rollback` removes by cask id** (`cask:homebrew/cask/notunes`) and only falls back to exact id if exit != 0. If remove-by-cid exits 0 while removing nothing (or the wrong element), the edge mis-evaluates silently. Add a list-verification between steps.
4. **Startup wait budget**: 4s + 10s poll may be short for Electron apps (vscode/cursor/obsidian) cold-starting in the VM → possible false startup=fail. The pristine-copy control launch is a good mitigations — interpret `startup=fail` as real **only if** the control also fails (or crash reports exist).
5. **Reading note, not a bug**: `remove.id_used == "casks"` in fresh results is correct — the first profile element gets the bare id, subsequent ones `casks-1..N` (confirmed in old trace). Ground truth is launcher_removed/profile_empty, both verified. Don't misread as the first-run alias bug.
6. Minor: baseline-cleanup asserts exit 0 per leftover entry and runs **before any save_state** — an unremovable leftover aborts with no results.json at all. `find_bundle_apps` falls back to `apps[0]` when the name-hint misses (could pick a helper bundle; detectable via `vendor_bundles_found`). Cursor CLI whitelisted as `code` — if not shipped, harmless `found:false`.

## Product defects (candidates; confirm against final results)
1. **Remove by ambiguous/alias id exited 0 while leaving sibling entries installed** (first run: `pkg remove casks` repeatedly exit 0, yet raycast/rectangle/alt-tab/maccy survived — profile ended with `casks-N` duplicates). Exit-0 no-op/partial remove is misleading; should error or demand exact id. Not re-tested by the sequential retry (single element ⇒ bare id is unambiguous) — needs the controlled proposal 3c below.
2. **Poor failure diagnostics**: audacity/calibre/obsidian failed with `Failed: install did not complete. / Cause: error:` — empty cause, and `nix log <drv>` returned nothing. Even under disk pressure a user gets no actionable signal. If failures recur on healthy disk, escalate from diagnostic gap to product bug.
3. Cosmetic: `warning: 'casks' is already added` printed on installs.
4. Confirmed-good so far: byte-identical install vs pristine (files+symlinks) 6/6; duplicate install is a manifest no-op; mix-valid+missing atomicity (first run: exit 1, manifest unchanged, valid token NOT installed); rollback restored prior generation with consistent entries.

## Infrastructure defects
1. First VM host-disk exhaustion caused Errno 92, the 3 "install did not complete" failures, and the corrupted cleanup cascade → addressed by fresh VM + 48GB freed. Guest now 53Gi free; remaining big casks (vscode/cursor/obsidian/audacity/calibre pristine downloads + extractions, ~1–2GB store growth) — keep an eye on df, no action needed now.
2. `nix log` for failing derivations returns empty in guest (no log retention) — weakens root-cause for any retry failure.
3. First-run profile pollution (duplicate casks-N elements) — now guarded by the baseline cleanup; assert-based abort is its own fragility (bug 6 above).

## Untested cases (not covered even when the 15-cycle + edges finish)
1. Foreign (native nixpkgs) entries sharing the pkg profile — does pkg remove/install preserve elements it doesn't own?
2. Cancellation during the *download/fetch* phase specifically (retry interrupts at 75s, likely build/realize for these sizes; SIGKILL path also untested — SIGINT is graceful).
3. Artifact/id conflicts: same cask via different spellings; two casks shipping the same .app name (first run accidentally created duplicate-looking entries — never deliberately exercised).
4. Remove while the app is still running (runner always SIGTERMs first).
5. Concurrent pkg invocations (lock contention), interrupted `apps sync`, pre-existing non-trampoline file at the trampoline path, Gatekeeper/quarantine on trampolines.

## Proposed adversarial checks for parent (after the 15-cycle; all read-mostly, task-scoped)
1. **Native co-install / removal preservation.** `nix profile install --profile $PROFILE nixpkgs#hello` (pin rev) → snapshot manifest v3 elements; `pkg install cask:homebrew/cask/stats`; verify list shows both + trampoline launches; `pkg remove <stats exact id>`; then assert: hello element byte-identical in manifest (attrPath/storePaths), its store path still present and valid, `pkg --json doctor` clean, native `nix profile list` intact. Pass = pkg never touches elements it doesn't own.
2. **True cancellation/retry in fetch phase.** Pick the largest uncached cask (cursor DMG ≈200MB); start `pkg install`, SIGINT at 10–15s (confirm fetch phase via growing tmp/cache dir), assert: manifest unchanged, no new generation, no partial files in $XDG_CACHE_HOME/XDG_STATE_HOME or /nix/store tmp; repeat with SIGKILL mid-fetch; then clean retry → install+launch+remove succeeds, store object count returns to baseline (no orphans).
3. **Conflict handling.** (a) same cask two spellings: `pkg install cask:homebrew/cask/utm` then bare `utm` (and `homebrew/cask/utm`) → expect exactly one element, no `casks-N` duplicate, duplicate-install semantics; (b) if eligible, two colliding-name casks (e.g., firefox vs firefox-esr) → expect explicit collision error or namespaced trampolines, and exact-id removal of one leaves the other installed AND launching; (c) deliberately `pkg remove casks` with ≥2 elements present → should error (or document semantics), never exit-0-partial — this closes product-defect candidate 1 with a controlled reproduction.

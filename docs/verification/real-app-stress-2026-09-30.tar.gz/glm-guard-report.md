# GLM-5.3 guard repair: external code-signature streams refused pre-write

Scope owned: `nix/casks/lib/plan.py` and `tools/cask-build-check/plan_tests.py` only.
No other files touched (parent's `openspec/changes/harden-native-package-lifecycle/{proposal,tasks}.md`
modifications were already present in the worktree and were left as-is).
No commits/pushes, no catalog pins, no vendor bytes, no VM runner, no Rust.

## Defect

Calibre 9.13.0 DMG: `Contents/Frameworks/plugins/python-lib.bypy.frozen` carries
external code-signature xattrs (`com.apple.cs.CodeDirectory`, `CodeEntitlements`,
`CodeRequirements`, `CodeRequirements-1`, `CodeSignature`). `7zz` materializes them
as members named `<file>:com.apple.cs.<attr>`, and `_prune_apple_streams` silently
deleted every `:com.apple.*` remnant, so the installed app failed
`codesign --verify --deep --strict` ("code object not signed at all, In subcomponent
python-lib.bypy.frozen"). The original DMG app verified strict.

## Repair (fail closed; no stripping, no re-sign, no name-based Calibre exclusion)

`nix/casks/lib/plan.py` (+38 lines, minimal):

1. New constants/helpers next to `APPLE_STREAM_MARK`:
   - `APPLE_CS_STREAM_MARK = ":com.apple.cs."`
   - `_is_codesign_stream(name)` — true when ANY path component contains the
     `:com.apple.cs.` signing-stream marker (7zz stream-name form).
   - `_die_external_signature(name)` — diagnostic:
     `cask-build: cannot preserve the external code signature of <member>: the Nix
     store cannot retain Apple code-signing streams (com.apple.cs.*); refusing to
     extract or prune them (no stripping, no re-sign)`.
2. PREFLIGHT: `sevenz_members` dies on any `:com.apple.cs.` member while parsing
   `7zz l -ba -slt` output — before the `-so` link reads, before
   `validate_members`, and before the `7zz x` write. All 7z/DMG paths route
   through `sevenz_members` (`extract_7zz`; `bsdtar_members` 7z-family branch),
   so no extraction write can occur for such an archive.
3. Defense in depth: `_prune_apple_streams` now dies instead of removing a
   `:com.apple.cs.*` name (both the dirnames and filenames loops), so a future
   refactor cannot silently strip signing streams through generic pruning.
4. Unrelated colon names (`notes:with:colons.txt`) and ordinary removable Apple
   metadata (`:com.apple.provenance`, `:com.apple.metadata:kMDItemWhereFroms`)
   keep their existing behavior: case 20 in the suite still passes (pruned /
   preserved respectively).

## Test (tools/cask-build-check/plan_tests.py, +79 lines)

Case 21 appended to the EXISTING native suite, reusing its real-`7zz` helper
`snl_archive` (`7zz a -snl` roundtrip, no subprocess mocks, no fake member lists):

- ONE real archive whose tree nests, inside `Cal.app/Contents/Frameworks/plugins/`,
  `python-lib.bypy.frozen` plus all five `:com.apple.cs.*` stream members, next to
  ordinary provenance/metadata streams and an unrelated colon name as controls
  (controls alone must not trigger refusal; their pruning is case 20's job).
- Runs `plan.extract_7zz` in a child interpreter (real 7zz on PATH) and asserts:
  exit 1; stderr contains `cannot preserve`, `external code signature`,
  `Nix store`, and the offending member
  `python-lib.bypy.frozen:com.apple.cs.CodeDirectory`; extraction area unchanged
  (`os.listdir(dest) == []`).
- Fails on previous behavior: verified by re-running the suite against
  `git show HEAD:nix/casks/lib/plan.py` — result
  `FAIL: external code-signature stream not refused: rc=0 dest=['Cal.app', 'Good.app', 'Fw.framework']`
  (i.e. the old code extracted "fine" with signing metadata silently stripped).

## Commands executed and results

- `PATH=/nix/store/4v5101d4a9cjxgdzd9z7bnrfd4rw5svp-7zz-26.01/bin:$PATH
  python3 tools/cask-build-check/plan_tests.py`
  (7zz is not on the default PATH of this shell; the suite treats a missing 7zz
  as a loud prerequisite failure, so the Nix store 7zz 26.01 was prepended)
  - after repair: `58` PASS lines, last line `all plan.py regression checks passed`, exit 0
  - against pre-repair `plan.py`: only failure is case 21 with
    `rc=0 dest=['Cal.app', 'Good.app', 'Fw.framework']`, exit 1 (regression proof)
- `python3 -m py_compile nix/casks/lib/plan.py tools/cask-build-check/plan_tests.py` — OK
- ad-hoc probe confirming 7zz lists the stream as an ordinary member (preflight
  sees it): `7zz l -ba -slt` shows
  `Path = .../python-lib.bypy.frozen:com.apple.cs.CodeDirectory`

## Coverage limits (explicit)

- Detection covers 7zz-materialized stream names of the form
  `<file>:com.apple.cs.<attr>` in any path component, for 7z/DMG (UDIF) archives.
- NOT covered: AppleDouble members (`__MACOSX/._foo`) inside ZIP archives, and
  tar/pax xattr headers (e.g. `LIBARCHIVE.xattr.com.apple.cs.*`). The stdlib
  zip/tar extractors never materialize xattrs, so such bytes would be installed
  as ordinary payload files; detecting them would require parsing AppleDouble
  bodies, which is deliberately out of scope here (stated in the code comment).
- Rejection is by stream marker, not by app name; any archive carrying such a
  stream is refused whole.

## Left to parent

- Actual Calibre 9.13.0 Nix build now expects a loud
  `cask-build: cannot preserve the external code signature ...` refusal
  (or a parent-side decision on how to ship signed frozen resources).
- Whole archive suite / CI re-run (`tools/cask-build-check/run.sh` needs a
  Nix-provided 7zz; not runnable from this shell's default PATH).

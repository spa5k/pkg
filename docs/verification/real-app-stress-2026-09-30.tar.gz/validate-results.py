import json,pathlib,sys
p=pathlib.Path(sys.argv[1]);d=json.loads(p.read_text()); summary=[]
for t,a in d["apps"].items():
 checks={
  "info":a.get("info",{}).get("exit")==0,
  "install":a.get("install",{}).get("exit")==0,
  "duplicate":a.get("duplicate_install",{}).get("exit")==0 and a.get("duplicate_install",{}).get("manifest_byte_identical") is True,
  "sync":a.get("apps_sync",{}).get("exit")==0 and a.get("trampoline_exists") is True,
  "signature":a.get("codesign_vendor",{}).get("exit")==0,
  "original_signature":a.get("pristine_codesign",{}).get("exit")==0,
  "contents":a.get("tree_compare",{}).get("equal") is True,
  "startup":a.get("open_exit")==0 and a.get("startup")=="pass" and bool(a.get("vendor_processes")),
  "remove":a.get("remove",{}).get("exit")==0 and a.get("remove",{}).get("id_used")==a.get("exact_entry_id"),
  "launcher_removed":a.get("launcher_removed") is True,
  "empty_profile":a.get("list_after_remove",{}).get("exit")==0 and a.get("list_after_remove",{}).get("entries")==[],
 }
 summary.append({"token":t,"version":a.get("catalog",{}).get("version"),"files":a.get("tree_compare",{}).get("installed_files"),"checks":checks,"pass":all(checks.values()),"error":a.get("error")})
out={"tested":len(summary),"passed":sum(a["pass"] for a in summary),"apps":summary}
print(json.dumps(out,indent=2));p.with_name("parent-summary.json").write_text(json.dumps(out,indent=2)+"\n")

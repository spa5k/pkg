package main
import "fmt"
func main(){fmt.Println("pkg-real-install: 42")}

module example.test/pkgprobe

go 1.24.0

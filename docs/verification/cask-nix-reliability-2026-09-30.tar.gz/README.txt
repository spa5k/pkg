The adjacent 2026-09-30-cask-nix-reliability.md is the final review.
Source SHA:58d802213be132ed8e78cd72719b8c374da4de3e.
Delegation used Pi zai/glm-5.3. Both E2B sandboxes were stopped.
delegated/ is raw agent evidence. Its report shortens the source SHA by mistake; source-sha256.json records the correct SHA. F3 is expected native entry-ID behavior.
parent/ contains independent native results. filtered-cancel-results.json covers default output mode, unlike the delegated verbose test.
metadata/ contains an offline compiled-generator reproduction of the erased maximum OS requirement.
baseline/ contains passed existing test logs.
No ELF builders, credentials, Nix store, or test homes are included. The raw sleep.c is an earlier invalid output fixture; do not use it as the successful retry source. The parent filtered-cancel fixture contains a valid builder.

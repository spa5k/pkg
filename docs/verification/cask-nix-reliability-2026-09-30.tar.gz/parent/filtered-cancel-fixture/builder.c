#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>
int main(int argc,char **argv){const char *out=getenv("out"); if(!out){puts("filtered-cancel probe");return 0;} sleep(6);char bin[4096],dst[4096];mkdir(out,0755);snprintf(bin,sizeof(bin),"%s/bin",out);mkdir(bin,0755);snprintf(dst,sizeof(dst),"%s/slow",bin);FILE *in=fopen(argv[1],"rb"),*to=fopen(dst,"wb");if(!in||!to)return 3;char buffer[8192];size_t n;while((n=fread(buffer,1,sizeof(buffer),in))>0)fwrite(buffer,1,n,to);fclose(in);fclose(to);chmod(dst,0755);return 0;}
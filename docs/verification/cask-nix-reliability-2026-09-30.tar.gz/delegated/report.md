# pkg/cask/Nix Reliability Audit — Final Report

Source: /home/user/workspace, exact tree 58d802213be132ed8e78cd72719b8c374da4de3.
Model: modelzai/glm-5.3. Prior native run timed out after 540 s; this report finalizes from
native logs and the incremental report only. No new tests were run. No production code edited.

- Source manifest: /home/user/audit/source-sha256.json — 910 files verified, 0 missing,
  0 mismatched, 0 extra tracked .rs/.toml under crates.
- Binaries: target/debug/pkg and target/debug/cask-catalog. Real nix 2.35.2 (Determinate 3.22.5).
- Fixture: git flake at git+file:///home/user/audit/fixtures/nixpkgs-fixture?ref=main; pure
  builtins.derivation with static-gcc builders. Fixture source kept (flake.nix, probe.c, sleep.c);
  ELF builder binaries excluded from evidence.
- Isolation homes home1..home4 and `home q'uote` under /home/user/audit (homes excluded from
  evidence; credentials/store never in scope).

## Case status (OBSERVED)

| Case | Status | Key observed exits |
|------|--------|--------------------|
| 1 journey | PASS | install-exit=0; rollback gen1; upgrade to 2.0.0 gen3 |
| 2 broken tap | PASS (defect found, see F1/F2) | install exit 1, no profile; doctor exit 0 |
| 3 adversarial CLI | PASS | badid-exit=1; dup exit 0; failedmulti exit 1, manifest unchanged |
| 4 archive plan.py | PASS | 4 adversarial zips exit 1 "unsafe archive member"/"member resolves above staging root"; good.zip exit 0. Executed natively — not SKIPPED |
| 5 cancellation | PASS | SIGINT -> pkg exit 130, no profile; retry2 installed cleanly, gen 1 |

## Findings (final classification)

### F1 — unrelated broken tap blocks qualified installs (concrete coupling issue)
- Trigger: registry.json valid, tap store `broken/apps` has malformed flake, no published
  generation. `pkg install nixpkgs:probe` -> exit 1: "tap source `broken/apps` is registered but
  has no published generation". Profile not created. Control home installs fine.
- Chain: lifecycle.rs:34 TapState::load -> tap/saved.rs:47 load() iterates all registered
  sources -> tap/store.rs:219 open_readonly error path.
- Classification: concrete coupling defect against the qualified-source isolation requirement of
  the namespaced-cask-catalog spec. Qualified `nixpkgs:` installs and explicit-flake installs must
  not depend on unrelated tap catalog state. Suggested fix: lazy catalog loading; only bare-name
  resolution, cask gates, and search need tap catalogs.

### F2 — doctor omits tap health (diagnostic gap)
- Same home: `pkg doctor --json` exits 0, all components green (nix runtime/daemon ok, sandbox
  blocked, profile fresh, config present), while install fails closed per F1.
- Classification: diagnostic gap, not a broad contract defect. Doctor should surface
  registered-but-unpublished taps so F1-class failures are explainable. Low severity.

### F3 — install ID does not round-trip to remove ID (expected behavior; UX improvement possible)
- Install `nixpkgs:foo.bar` records native entry ID `bar` (final attrpath segment).
  `pkg remove foo.bar` -> exit 1 "not an installed entry"; `pkg remove bar` works.
- Classification: REQUIRED by the native-profile-lifecycle spec — entry IDs are nix final
  attrpath segments. Not a defect. Possible UX improvement: install output and/or remove could
  map or hint the recorded entry ID.

## Non-findings (checked, correct)
- Remove removes only the exact entry; `probe+` refused by ID grammar (expected strict rule).
- Duplicate install: exit 0 "Unchanged". Bad ID / failed multi: exit 1, manifest byte-identical,
  generation number unchanged.
- HOME/XDG with space and single quote: doctor, install, run, remove all pass (case3-spaces logs).
- `--json` on install/remove refused by design.

## Case notes

- Case 1: doctor fresh -> install (real git+file fetch + real build) -> run marker
  "audit-probe 1.0.0" -> `--json list` entry `probe`, locked_source carries rev -> remove gen2 ->
  rollback gen1 (restored binary runs) -> history 2,1(current) -> prune none -> moving-source
  upgrade to "audit-probe 2.0.0" gen3. Cosmetic: top-level `nixpkgs` key in config.toml silently
  ignored; key must be under `[sources]`.
- Case 2: also confirmed explicit `git+file://...#probe` refused ("only public github:
  references are supported") — documented design limit.
- Case 5: SIGINT to pkg PID after 4 s; builder slept 20 s. pkg exit 130 "Interrupted: install
  stopped. Installed entries unchanged." No profile, no stale state. Two distinct events:
  (a) one earlier failure was a fixture defect — the sleep builder did not create $out (fixture
  timeout/build failure), NOT a product failure; (b) after fixture fix, retry2 (slow builder
  changed 30 s -> 5 s) rebuilt from scratch and installed cleanly, gen 1, entry `probe-slow`.
  Product behavior was correct in both. Cancellation was exercised via the verbose (Stream)
  path only; defaultFiltered was NOT tested — no claim is made about it.

## Evidence limits
- Log files are the native-run logs; per-command exit codes are present only where logged
  (e.g. install-exit=0, badid-exit=1). Counts are not invented for log lines that are absent.
- Linux only. macOS GUI, Gatekeeper, app launchers not provable (doctor: skipped).
- Tap sandbox blocked (sandbox=true), so `pkg tap add` consent flow not exercisable offline;
  broken tap was crafted on disk.
- Fixed-revision skip logic (is_fixed_reference) was source-read only; not natively exercised.
- No full nixpkgs search/evaluation or network downloads, except one accidental real-github
  nixpkgs fetch in the first install attempt before `[sources]` was set.
- No fixes, PRs, releases, or model credentials are part of this audit.

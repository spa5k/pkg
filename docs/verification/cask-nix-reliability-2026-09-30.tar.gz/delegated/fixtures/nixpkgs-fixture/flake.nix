{
  description = "pkg audit fixture";
  outputs = { self }: let
    system = "x86_64-linux";
    probe1 = builtins.derivation {
      name = "audit-probe-1";
      system = "x86_64-linux";
      builder = ./builder-v1;
      args = [ ];
    };
    foobar = builtins.derivation {
      name = "audit-foo-bar";
      system = "x86_64-linux";
      builder = ./builder-foobar;
      args = [ ];
    };
    fooxbar = builtins.derivation {
      name = "audit-fooXbar";
      system = "x86_64-linux";
      builder = ./builder-fooxbar;
      args = [ ];
    };
    probe2 = builtins.derivation {
      name = "audit-probe-2";
      system = "x86_64-linux";
      builder = ./builder-v2;
      args = [ ];
    };
    probeSlow = builtins.derivation {
      name = "audit-probe-slow";
      system = "x86_64-linux";
      builder = ./builder-sleep;
      args = [ ];
    };
    withMeta = drv: pname: version: drv // {
      inherit pname version;
      meta = { description = "pkg audit fixture probe"; platforms = [ "x86_64-linux" ]; };
    };
  in rec {
    packages.${system} = {
      probe = withMeta probe2 "probe" "2";
      fooXbar = withMeta fooxbar "fooXbar" "1";
      "probe+" = withMeta probe1 "probe+" "1";
      foo.bar = withMeta foobar "foo.bar" "1";
      probe-slow = withMeta probeSlow "probe-slow" "1";
    };
    # v2 staging attr for the upgrade step, not exposed as default
    legacyPackages.${system}.probe = withMeta probe1 "probe" "1";
    v2 = { probe = withMeta probe2 "probe" "2"; };
  };
}

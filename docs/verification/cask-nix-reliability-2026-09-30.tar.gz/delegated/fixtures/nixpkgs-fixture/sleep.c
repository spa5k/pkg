#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>
int main(void){
  const char *out = getenv("out");
  if (out && *out) { sleep(20); mkdir(out, 0755); FILE *f = fopen("/dev/null","r"); return 0; }
  puts("probe-slow 1.0.0"); return 0;
}

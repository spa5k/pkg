#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#ifndef OUTBIN
#define OUTBIN "probe"
#endif
int main(int argc, char **argv) {
    const char *out = getenv("out");
    if (out && *out) {
        char buf[4096];
        snprintf(buf, sizeof buf, "%s/bin", out);
        mkdir(out, 0755);
        if (mkdir(buf, 0755) != 0 && access(buf, W_OK) != 0) { perror("mkdir"); return 1; }
        int in = open("/proc/self/exe", O_RDONLY);
        if (in < 0) { perror("open self"); return 1; }
        snprintf(buf, sizeof buf, "%s/bin/" OUTBIN, out);
        int fd = open(buf, O_WRONLY|O_CREAT|O_TRUNC, 0755);
        if (fd < 0) { perror("open dest"); return 1; }
        ssize_t n; char chunk[65536];
        while ((n = read(in, chunk, sizeof chunk)) > 0) {
            char *p = chunk; ssize_t w;
            while (n > 0) { w = write(fd, p, n); if (w <= 0) { perror("write"); return 1; } p += w; n -= w; }
        }
        close(in); close(fd);
        return 0;
    }
    puts(MARKER);
    return 0;
}

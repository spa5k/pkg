import json
import os
from pathlib import Path
import shutil
import subprocess

base = Path('/home/user/parent-audit')
base.mkdir(exist_ok=True)
pkg = '/home/user/workspace/target/debug/pkg'
fixture = Path('/home/user/audit/fixtures/nixpkgs-fixture')
source = base / ('a' * 40)
shutil.copytree(fixture, source, ignore=shutil.ignore_patterns('.git'), dirs_exist_ok=True)
flake = (source / 'flake.nix').read_text()
v1 = flake.replace('probe = withMeta probe2 "probe" "2";', 'probe = withMeta probe1 "probe" "1";')
(source / 'flake.nix').write_text(v1)
results = []

def home(name, reference):
    h = base / name
    (h / '.config/pkg').mkdir(parents=True, exist_ok=True)
    (h / '.config/pkg/config.toml').write_text('[sources]\nnixpkgs = ' + json.dumps(reference) + '\ncasks = ' + json.dumps(reference) + '\n')
    env = dict(os.environ, HOME=str(h), XDG_STATE_HOME=str(h / '.local/state'), XDG_CACHE_HOME=str(h / '.cache'), XDG_CONFIG_HOME=str(h / '.config'))
    env['NIX_CONFIG'] = 'experimental-features = nix-command flakes'
    return h, env

def run(tag, argv, env):
    try:
        r = subprocess.run(argv, env=env, text=True, capture_output=True, timeout=20)
        row = dict(tag=tag, argv=argv, exit=r.returncode, stdout=r.stdout, stderr=r.stderr)
    except subprocess.TimeoutExpired:
        row = dict(tag=tag, argv=argv, timeout=True)
    results.append(row)
    (base / 'results.json').write_text(json.dumps(results, indent=2))
    print(json.dumps(row), flush=True)
    return row

h, env = home('hex-path', 'path:' + str(source))
profile = h / '.local/state/nix/profiles/pkg'
run('hex-path-install-v1', [pkg, 'install', 'nixpkgs:probe'], env)
run('hex-path-run-v1', [str(profile / 'bin/probe')], env)
(source / 'flake.nix').write_text(flake)
run('hex-path-upgrade-v2', [pkg, 'upgrade', '--all'], env)
run('hex-path-run-after-pkg-upgrade', [str(profile / 'bin/probe')], env)
run('hex-path-native-upgrade', ['nix', 'profile', 'upgrade', '--profile', str(profile), '--all'], env)
run('hex-path-run-after-native-upgrade', [str(profile / 'bin/probe')], env)

ref = 'git+file://' + str(fixture) + '?ref=main'
h2, env2 = home('corrupt-profile', ref)
p2 = h2 / '.local/state/nix/profiles/pkg'
p2.mkdir(parents=True, exist_ok=True)
(p2 / 'manifest.json').write_text('{"version":3,"elements":[]}')
run('corrupt-profile-list', [pkg, '--json', 'list'], env2)
run('corrupt-profile-info', [pkg, '--json', 'info', 'nixpkgs:probe'], env2)

h3, env3 = home('dangling-profile', ref)
p3 = h3 / '.local/state/nix/profiles/pkg'
p3.parent.mkdir(parents=True, exist_ok=True)
p3.symlink_to('/nix/store/nonexistent-audit-profile')
run('dangling-profile-native-list', ['nix', 'profile', 'list', '--profile', str(p3), '--json'], env3)
run('dangling-profile-pkg-list', [pkg, '--json', 'list'], env3)
run('dangling-profile-pkg-doctor', [pkg, '--json', 'doctor'], env3)

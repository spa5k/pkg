import importlib.util
import json
import os
from pathlib import Path
import subprocess
import time

T = Path('/Users/admin/pkg-app-space-test')
CACHE = Path('/nix/var/pkg-app-space-test/501')
spec = importlib.util.spec_from_file_location('runtime', T / 'app-runtime.py')
runtime = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runtime)
records = {}

def run(args):
    p = subprocess.run(list(map(str, args)), capture_output=True, text=True, check=True)
    return p.stdout

def available():
    info = os.statvfs(CACHE)
    return info.f_bavail * info.f_frsize

for token, baseline in json.loads((T / 'compression-probe.json').read_text()).items():
    source = Path(baseline['store'])
    control = Path(baseline['cached'])
    resource = 'Contents/Frameworks/plugins/python-lib.bypy.frozen' if token == 'calibre' else 'Contents/Resources/obsidian.asar'
    attributes = {a: runtime.get_attribute(control / resource, a).hex() for a in runtime.attribute_names(control / resource) if a.startswith('com.apple.cs.')}
    signatures = {resource: attributes}
    cached = CACHE / source.name
    before = available()
    started = time.monotonic()
    runtime.copy_payload(source, cached)
    copied = time.monotonic() - started
    target = cached / resource
    mode = target.stat().st_mode & 0o777
    os.chmod(target, mode | 0o200)
    for key, value in attributes.items():
        runtime.set_attribute(target, key, bytes.fromhex(value))
    os.chmod(target, mode)
    runtime.verify(cached, signatures, source)
    after = available()
    assert source.stat().st_dev == cached.stat().st_dev
    assert (source / resource).stat().st_ino != target.stat().st_ino
    assert not any(a.startswith('com.apple.cs.') for a in runtime.attribute_names(source / resource))
    run(['/usr/bin/open', '-n', cached])
    found = []
    for _ in range(60):
        text = run(['/bin/ps', '-axo', 'pid=,command='])
        found = [line.strip().split(None, 1) for line in text.splitlines() if len(line.strip().split(None, 1)) == 2 and line.strip().split(None, 1)[1].startswith(str(cached) + '/Contents/')]
        if found:
            break
        time.sleep(.5)
    assert found, token
    for pid, _ in found:
        try:
            os.kill(int(pid), 9)
        except ProcessLookupError:
            pass
    records[token] = {'version': baseline['version'], 'logical_bytes': baseline['source_size']['logical_bytes'], 'observed_free_space_change_bytes': before - after, 'copy_seconds': copied, 'separate_inodes': True, 'store_signatures_unchanged': True, 'native_signature_verification': True, 'startup': True}
    (T / 'clone-probe.json').write_text(json.dumps(records, indent=2))
    print(token + ': ' + json.dumps(records[token]), flush=True)

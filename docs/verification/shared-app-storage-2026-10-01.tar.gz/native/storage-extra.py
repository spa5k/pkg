import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess

T = Path('/Users/admin/pkg-app-space-test')
data = json.loads((T / 'lifecycle.json').read_text())
records = {}

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for part in iter(lambda: f.read(1024 * 1024), b''):
            h.update(part)
    return h.hexdigest()

def run(args, env=None):
    p = subprocess.run(list(map(str, args)), capture_output=True, text=True, env=env)
    return {'exit': p.returncode, 'out': p.stdout, 'err': p.stderr}

for token, name in [('calibre', 'calibre.app'), ('obsidian', 'Obsidian.app')]:
    output = Path(data['apps'][token]['output'])
    helper = output / 'libexec/pkg-cask-app'
    source = output / 'libexec/pkg/app-sources' / name
    copy = Path(data['apps'][token]['cache'])
    resource = 'Contents/Frameworks/plugins/python-lib.bypy.frozen' if token == 'calibre' else 'Contents/Resources/obsidian.asar'
    target = copy / resource
    before = digest(source / resource)
    mode = target.stat().st_mode & 0o777
    os.chmod(target, mode | 0o200)
    with target.open('r+b') as f:
        original = f.read(1)
        f.seek(0)
        f.write(bytes([original[0] ^ 1]))
    os.chmod(target, mode)
    assert digest(source / resource) == before
    assert digest(target) != before
    repair = run([helper, 'prepare', name])
    assert repair['exit'] == 0, repair
    assert digest(target) == digest(source / resource) == before
    other = T / ('other-volume-' + token)
    other.mkdir(mode=0o700)
    env = dict(os.environ, PKG_APP_CACHE_DIR=str(other))
    refused = run([helper, 'prepare', name], env)
    assert refused['exit'] == 1 and 'Nix store volume' in refused['err'], refused
    assert not list(other.iterdir())
    setup = run([T / 'pkg', 'apps', 'setup'], env)
    assert setup['exit'] == 1 and 'Nix store volume' in setup['err'], setup
    assert 'Preparing app storage' not in setup['err']
    records[token] = {'private_write_did_not_change_store': True, 'damaged_data_repaired': True, 'cross_volume_prepare': refused, 'cross_volume_setup': setup}

import fcntl
import struct
for token, name in [('calibre', 'calibre.app'), ('obsidian', 'Obsidian.app')]:
    output = Path(data['apps'][token]['output'])
    source = output / 'libexec/pkg/app-sources' / name
    cached = Path(data['apps'][token]['cache'])
    total = shared = count = 0
    for root, _dirs, files in os.walk(source, followlinks=False):
        for name in files:
            path = Path(root) / name
            if path.is_symlink() or not path.is_file():
                continue
            copy = cached / path.relative_to(source)
            assert path.stat().st_ino != copy.stat().st_ino
            size = path.stat().st_size
            total += size
            count += 1
            with path.open('rb') as a, copy.open('rb') as b:
                offset = 0
                while offset < size:
                    query = struct.pack('=Iqq', 0, size - offset, offset)
                    _fa, la, ba = struct.unpack('=Iqq', fcntl.fcntl(a.fileno(), 65, query))
                    _fb, lb, bb = struct.unpack('=Iqq', fcntl.fcntl(b.fileno(), 65, query))
                    assert ba >= 0 and ba == bb
                    length = min(la, lb, size - offset)
                    assert length > 0
                    shared += length
                    offset += length
    assert total == shared
    records[token]['shared_data'] = {'files': count, 'total_file_bytes': total, 'shared_bytes': shared, 'every_extent_shared': True}
    print(token + ': ' + json.dumps(records[token]), flush=True)

(T / 'shared-storage-proof.json').write_text(json.dumps(records, indent=2))

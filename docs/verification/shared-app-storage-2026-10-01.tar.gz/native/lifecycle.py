import hashlib, importlib.util, json, os, pathlib, plistlib, shutil, signal, stat, subprocess, time

T = pathlib.Path('/Users/admin/pkg-app-space-test')
HOME = T/'home'
PROFILE = T/'state/nix/profiles/pkg'
PKG = T/'pkg'
NIX = '/nix/var/nix/profiles/default/bin/nix'
os.environ.update(HOME=str(HOME), XDG_STATE_HOME=str(T/'state'), XDG_CONFIG_HOME=str(T/'config'), XDG_CACHE_HOME=str(T/'cache'), PATH='/nix/var/nix/profiles/default/bin:/usr/bin:/bin:/usr/sbin:/sbin')
R = {'apps':{},'edges':{}}
LOG = T/'lifecycle-logs'
LOG.mkdir(exist_ok=True)
counter = 0
def save(): (T/'lifecycle.json').write_text(json.dumps(R,indent=2))
def run(args, timeout=900, required=True):
    global counter
    counter += 1
    args = list(map(str,args))
    p = subprocess.run(args,capture_output=True,text=True,timeout=timeout)
    rec = {'args':args,'exit':p.returncode,'out':p.stdout,'err':p.stderr}
    (LOG/('%03d.json'%counter)).write_text(json.dumps(rec,indent=2))
    if required and p.returncode: raise RuntimeError(json.dumps(rec)[:2000])
    return rec
def pkg(*args): return run([PKG]+list(args))
def entries(): return json.loads(run([NIX,'profile','list','--profile',PROFILE,'--json'])['out'])['elements']
def fingerprint(): return hashlib.sha256((PROFILE/'manifest.json').read_bytes()).hexdigest()
def hashfile(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
    return h.hexdigest()
def tree(root):
    found={}
    for base,dirs,files in os.walk(root,followlinks=False):
        for name in dirs+files:
            p=pathlib.Path(base)/name
            rel=str(p.relative_to(root))
            if p.is_symlink(): found[rel]=['link',os.readlink(p)]
            elif p.is_file(): found[rel]=['file',hashfile(p),bool(p.stat().st_mode & 0o111)]
    return found
def processes(bundle):
    text=run(['/bin/ps','-axo','pid=,command='])['out']
    return [(int(line.strip().split(None,1)[0]),line.strip().split(None,1)[1]) for line in text.splitlines() if len(line.strip().split(None,1))==2 and line.strip().split(None,1)[1].startswith(str(bundle)+'/Contents/')]
def start(launcher,bundle):
    run(['/usr/bin/open','-n',launcher])
    for _ in range(60):
        found=processes(bundle)
        if found: return found
        time.sleep(.5)
    raise RuntimeError('no native process at '+str(bundle))
def stop(bundle):
    for pid,_ in processes(bundle):
        try: os.kill(pid,signal.SIGTERM)
        except ProcessLookupError: pass
    time.sleep(1)
    for pid,_ in processes(bundle):
        try: os.kill(pid,signal.SIGKILL)
        except ProcessLookupError: pass
    time.sleep(.3)
R['setup']=pkg('apps','setup')
R['setup_repeat']=pkg('apps','setup')
for key in list(entries()): pkg('remove',key)
for token,name in [('calibre','calibre.app'),('obsidian','Obsidian.app'),('stats','Stats.app')]:
    print('Lifecycle: '+token,flush=True)
    rec=R['apps'][token]={}
    rec['install']=pkg('install','cask:'+token)
    data=entries()
    assert len(data)==1, data
    key,entry=next(iter(data.items()))
    output=pathlib.Path(entry['storePaths'][0])
    rec['output']=str(output)
    signed=(output/'share/pkg/cask-apps.json').exists()
    if signed:
        manifest=json.loads((output/'share/pkg/cask-apps.json').read_text())
        item=manifest['apps'][name]
        bundle=pathlib.Path('/nix/var/pkg/cask-apps')/str(os.getuid())/output.name/name
        assert not (output/'Applications'/name).exists()
        native=output/'libexec/pkg/cask-app.py'
        spec=importlib.util.spec_from_file_location('runtime',native)
        runtime=importlib.util.module_from_spec(spec);spec.loader.exec_module(runtime)
        rec['signatures']={}
        for path,attrs in item['signatures'].items():
            actual={attr:runtime.get_attribute(bundle/path,attr).hex() for attr in attrs}
            assert actual==attrs
            rec['signatures'][path]={'bytes_match':True,'verify':run(['/usr/bin/codesign','--verify','--strict',bundle/path])}
        rec['payload_equal']=tree(output/item['source'])==tree(bundle)
        assert rec['payload_equal']
        # Compare the independent original-vendor control, not just our output.
        original=pathlib.Path(json.loads((T/'proof.json').read_text())[token]['store'])
        rec['original_files_equal']=tree(original)==tree(bundle)
        assert rec['original_files_equal']
        helper=output/'libexec/pkg-cask-app'
        rec['cache']=str(bundle)
    else:
        bundle=output/'Applications'/name
    rec['bundle_verify']=run(['/usr/bin/codesign','--verify','--deep','--strict',bundle])
    rec['list']=pkg('list','--json')
    old=fingerprint()
    rec['duplicate']=pkg('install','cask:'+token)
    assert fingerprint()==old
    rec['sync']=pkg('apps','sync')
    launcher=HOME/'Applications/pkg'/name
    rec['processes']=start(launcher,bundle)
    if token=='calibre':
        rec['cli']=run([PROFILE/'bin/ebook-convert','--version'],timeout=60)
        assert '9.13.0' in rec['cli']['out']
    if token=='obsidian': rec['cli']=run([PROFILE/'bin/obsidian','version'],timeout=60,required=False)
    stop(bundle)
    if signed:
        # Damaged signatures are rebuilt from the immutable payload.
        path,attrs=next(iter(item['signatures'].items()))
        target=bundle/path
        mode=stat.S_IMODE(target.stat().st_mode)
        os.chmod(target,mode|stat.S_IWUSR)
        runtime.set_attribute(target,'com.apple.cs.CodeDirectory',b'damaged')
        os.chmod(target,mode)
        rec['repair']=run([helper,'prepare',name])
        assert fingerprint()==old
        assert runtime.get_attribute(bundle/path,'com.apple.cs.CodeDirectory').hex()==attrs['com.apple.cs.CodeDirectory']
        rec['repair_verify']=run(['/usr/bin/codesign','--verify','--deep','--strict',bundle])
    rec['remove']=pkg('remove',key)
    assert entries()=={} and not launcher.exists()
    rec['rollback']=pkg('rollback')
    assert len(entries())==1
    rec['rollback_processes']=start(launcher,bundle)
    stop(bundle)
    for key in list(entries()): pkg('remove',key)
    save()

    if signed and token=='calibre':
        # Cancellation during the actual copy, not a mocked command.
        runtime.remove_copy(bundle)
        env=os.environ.copy()
        child=subprocess.Popen([str(helper),'prepare',name],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        observed=False
        for _ in range(500):
            areas=list(bundle.parent.glob('.prepare-*'))
            if any((p/name/'Contents').exists() for p in areas): observed=True;break
            if child.poll() is not None: break
            time.sleep(.01)
        assert observed,'did not observe active copy'
        child.send_signal(signal.SIGINT)
        out,err=child.communicate(timeout=60)
        assert child.returncode==130,(child.returncode,out,err)
        assert not bundle.exists() and not list(bundle.parent.glob('.prepare-*'))
        R['edges']['cancel']={'exit':child.returncode,'copy_observed':True,'published':False,'out':out,'err':err}
        # Concurrent real callers serialize and both see a verified copy.
        a=subprocess.Popen([str(helper),'prepare',name],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        b=subprocess.Popen([str(helper),'prepare',name],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        oa,ea=a.communicate(timeout=120);ob,eb=b.communicate(timeout=120)
        assert a.returncode==b.returncode==0,(ea,eb)
        assert oa==ob and bundle.exists() and not list(bundle.parent.glob('.prepare-*'))
        R['edges']['concurrent']={'exits':[a.returncode,b.returncode],'same_path':True}
        # Refuse an unowned version folder and a cache ancestor symlink.
        for kind in ('unowned','symlink'):
            home=T/('home-'+kind);home.mkdir(mode=0o700,exist_ok=True)
            parent=pathlib.Path('/nix/var/pkg-app-space-test')/str(os.getuid())/kind
            parent.mkdir(parents=True,mode=0o700)
            victim=parent/output.name
            sentinel=T/('sentinel-'+kind);sentinel.mkdir();(sentinel/'keep').write_text('unchanged')
            if kind=='unowned': victim.mkdir()
            else: victim.symlink_to(sentinel,target_is_directory=True)
            result=subprocess.run([str(helper),'prepare',name],env=dict(os.environ,HOME=str(home),PKG_APP_CACHE_DIR=str(parent)),capture_output=True,text=True)
            assert result.returncode==1 and (sentinel/'keep').read_text()=='unchanged'
            assert not (victim/name).exists()
            R['edges'][kind]={'exit':result.returncode,'err':result.stderr,'sentinel_unchanged':True}
        save()
R['profile_empty']=entries()=={}
save()
print(json.dumps({k:{'install':v['install']['exit'],'signature':v['bundle_verify']['exit'],'startup':bool(v['processes']),'remove':v['remove']['exit'],'rollback':v['rollback']['exit']} for k,v in R['apps'].items()}),flush=True)

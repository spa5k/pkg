import fcntl
import json
import os
from pathlib import Path
import struct

T = Path('/Users/admin/pkg-app-space-test')
CACHE = Path('/nix/var/pkg-app-space-test/501')
records = {}
def extent(fd, offset, length):
    # Apple's SDK packs struct log2phys at four-byte alignment.
    data = fcntl.fcntl(fd, 65, struct.pack('=Iqq', 0, length, offset))
    _flags, contiguous, physical = struct.unpack('=Iqq', data)
    return physical, contiguous

for token, baseline in json.loads((T / 'compression-probe.json').read_text()).items():
    source = Path(baseline['store'])
    cached = CACHE / source.name
    mapped = shared = total = count = 0
    failures = []
    for root, _dirs, files in os.walk(source, followlinks=False):
        for name in files:
            path = Path(root) / name
            if path.is_symlink() or not path.is_file():
                continue
            copy = cached / path.relative_to(source)
            size = path.stat().st_size
            total += size
            count += 1
            with path.open('rb') as a, copy.open('rb') as b:
                offset = 0
                try:
                    while offset < size:
                        original, length_a = extent(a.fileno(), offset, size - offset)
                        cloned, length_b = extent(b.fileno(), offset, size - offset)
                        length = min(length_a, length_b, size - offset)
                        assert length > 0, 'empty mapped extent'
                        mapped += length
                        if original == cloned and original >= 0:
                            shared += length
                        else:
                            failures.append(str(path.relative_to(source)))
                        offset += length
                except OSError as error:
                    failures.append([str(path.relative_to(source)), str(error)])
    records[token] = {'files': count, 'total_file_bytes': total, 'mapped_bytes': mapped, 'shared_bytes': shared, 'failures': failures}
    print(token + ': ' + json.dumps(records[token]), flush=True)
    assert not failures and mapped == total == shared
    (T / 'shared-extents.json').write_text(json.dumps(records, indent=2))

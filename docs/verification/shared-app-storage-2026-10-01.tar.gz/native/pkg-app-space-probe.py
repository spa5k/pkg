import hashlib
import importlib.util
import json
import os
from pathlib import Path
import plistlib
import stat
import subprocess
import time

T = Path('/Users/admin/pkg-app-space-test')
T.mkdir(exist_ok=True)
NIX = '/nix/var/nix/profiles/default/bin/nix'
spec = importlib.util.spec_from_file_location('runtime', T / 'app-runtime.py')
runtime = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runtime)
records = {}

def run(args, timeout=900):
    p = subprocess.run(list(map(str, args)), capture_output=True, text=True, timeout=timeout)
    if p.returncode:
        raise RuntimeError(str(args) + '\n' + p.stderr[:1000])
    return p.stdout

def digest(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def inventory(root):
    result = {}
    for base, dirs, files in os.walk(root, followlinks=False):
        for name in dirs + files:
            path = Path(base) / name
            rel = str(path.relative_to(root))
            if path.is_symlink():
                result[rel] = ['link', os.readlink(path)]
            elif path.is_file():
                result[rel] = ['file', digest(path), bool(path.stat().st_mode & 0o111)]
    return result

def size(root):
    paths = [root]
    for base, dirs, files in os.walk(root, followlinks=False):
        paths.extend(Path(base) / name for name in dirs + files)
    return {'logical_bytes': sum(p.lstat().st_size for p in paths if p.is_file() and not p.is_symlink()),
            'du_bytes': int(run(['/usr/bin/du', '-sk', root]).split()[0]) * 1024,
            'compressed_files': sum(bool(p.lstat().st_flags & 0x20) for p in paths if p.is_file() and not p.is_symlink())}

plans = json.loads((T / 'apps.json').read_text())
for token in ['calibre', 'obsidian']:
    entry = plans[token]
    dmg = T / (token + '.dmg')
    source = entry['plan']['source']
    if not dmg.exists():
        print('Download ' + token, flush=True)
        run(['/usr/bin/curl', '-fL', '--retry', '2', '-o', dmg, source['url']])
    assert digest(dmg) == source['sha256']
    p = subprocess.run(['/usr/bin/hdiutil', 'attach', '-readonly', '-nobrowse', '-plist', str(dmg)], capture_output=True, check=True)
    mounts = [Path(x['mount-point']) for x in plistlib.loads(p.stdout)['system-entities'] if 'mount-point' in x]
    name = next(x['target'] for x in entry['plan']['artifacts'] if x['kind'] == 'app')
    original = next(m / name for m in mounts if (m / name).exists())
    try:
        resource = 'Contents/Frameworks/plugins/python-lib.bypy.frozen' if token == 'calibre' else 'Contents/Resources/obsidian.asar'
        target = original / resource
        attributes = {a: runtime.get_attribute(target, a) for a in runtime.attribute_names(target) if a.startswith('com.apple.cs.')}
        store = Path(run([NIX, '--extra-experimental-features', 'nix-command flakes', 'store', 'add-path', original]).strip())
        cached = T / ('compressed-' + name)
        started = time.monotonic()
        run(['/usr/bin/ditto', '--hfsCompression', '--noclone', '--rsrc', '--extattr', '--noacl', store, cached])
        elapsed = time.monotonic() - started
        target = cached / resource
        mode = stat.S_IMODE(target.stat().st_mode)
        os.chmod(target, mode | stat.S_IWUSR)
        for key, value in attributes.items():
            runtime.set_attribute(target, key, value)
        os.chmod(target, mode)
        run(['/usr/bin/codesign', '--verify', '--strict', target])
        run(['/usr/bin/codesign', '--verify', '--deep', '--strict', cached])
        assert inventory(original) == inventory(cached)
        assert attributes == {a: runtime.get_attribute(target, a) for a in attributes}
        processes = []
        run(['/usr/bin/open', '-n', cached])
        for _ in range(60):
            lines = run(['/bin/ps', '-axo', 'pid=,command=']).splitlines()
            processes = [line.strip().split(None, 1) for line in lines if len(line.strip().split(None, 1)) == 2 and line.strip().split(None, 1)[1].startswith(str(cached) + '/Contents/')]
            if processes:
                break
            time.sleep(.5)
        assert processes, 'No app process: ' + token
        for pid, _ in processes:
            try:
                os.kill(int(pid), 9)
            except ProcessLookupError:
                pass
        record = {'version': entry['version'], 'store': str(store), 'cached': str(cached), 'source_size': size(store), 'cache_size': size(cached), 'copy_seconds': elapsed, 'vendor_files_equal': True, 'vendor_signature_attributes_equal': True, 'native_signature_verification': True, 'startup': True}
        records[token] = record
        (T / 'compression-probe.json').write_text(json.dumps(records, indent=2))
        print(token + ': ' + json.dumps(record), flush=True)
    finally:
        for mount in mounts:
            run(['/usr/bin/hdiutil', 'detach', mount])
